# Placeholder figures to replace

Every number below is authored, not measured. Fill the "measured" column, then
run `bash build/build.sh` and check the three documents still read coherently —
several figures are derived from others and will need recalculating together.

Delete this file once it is empty, and record the replacement in
`DECISIONS.md`.

---

## 1 · Organisation sizing
Appears in: TOM Figure 2 and Appendix B.

| Item | Authored | Measured | Source |
|---|---|---|---|
| Investment platform | ≈50 | | |
| Client platform | ≈35 | | |
| Corporate platform | ≈40 | | |
| Intelligence Platform | ≈35 | | |
| CTOO office | ≈20 | | |
| Software Engineering chapter | ≈70 | | |
| Business Analysis & Design | ≈30 | | |
| Platform & Reliability Engineering | ≈40 | | |
| Data & Knowledge Engineering | ≈30 | | |
| Architects | 5 + head | | |
| AI Assurance | 3 + head | | |
| Delivery coaches | 3 | | |
| FDEs per business platform | 2–3 | | |

**Also settle:** which of the seventeen products' POs actually move to the
business. The document says "about half"; the real answer depends on whether
Finance & Oversight and Regulatory & Control report into your side.

## 2 · Reconciliation baseline
Appears in: guide A.3, and every derived figure in guide A.11, A.14–A.17 and
pod manual A.8. **Changing any of these means recalculating all of them.**

| Measure | Authored | Measured | Notes |
|---|---|---|---|
| Breaks per day, mean | 410 | | |
| Month-end / quarter-end peak | 980 / 1,340 | | |
| Cases needing human work | 172/day | | The denominator for everything |
| Median cycle time | 1.4 days | | |
| 90th percentile cycle time | 9 days | | The number the business feels |
| Touch time per worked case | 7.5 min | | Sample it; do not estimate |
| Fully loaded hourly rate | CHF 91 | | Ask Finance for the standard rate |
| Cost per worked case | CHF 11.40 | | Derived from the two above |
| Mis-categorisation rate | ≈9% | | Most teams have never measured this |
| Difficulty split | 71/21/8 | | Routine / thought / hard |
| Aged breaks over 30 days | 64 | | |
| Portfolios / custodians in scope | 400 / 11 | | |

## 3 · Loop economics
Appears in: guide A.14–A.17.

| Item | Authored | Measured |
|---|---|---|
| Build — business manager days | 15 | |
| Build — golden-set adjudication days | 7 | |
| Build — analyst days | 25 | |
| Build — engineering days | 40 | |
| Build — assurance days | 8 | |
| Build — platform onboarding | CHF 28,000 | |
| Agent cost per case | CHF 0.18 | From the gateway, tagged |
| Platform share per case | CHF 0.42 | Ask the Intelligence Platform |
| Maintenance per year | CHF 31,000 | |
| Rework per case | CHF 0.20 | |
| Amortisation period | 3 years | |

Derived and needing recomputation: steady-state and fully loaded cost per
case, payback period, break-even volume, the like-for-like comparison, and the
second-loop discount in A.17.

## 4 · Shadow and evaluation figures
Appears in: guide A.7–A.9, pod manual A.6.

| Item | Authored | Measured |
|---|---|---|
| Golden set size | 340 | |
| Initial adjudicator agreement | 83% | |
| Shadow quadrants | 84 / 4 / 9 / 1 / 2 | |
| Gate thresholds | 88% overall, 80% per category | |
| Categories granted tier 2 | 4 of 9 | |
| Share of worked volume at tier 2 | 61% | |

## 5 · Pilots — not numbers, but outstanding
- Which three products. The guide and TOM name domains, not products.
- Who leads each pilot. Three named people turn an intention into a decision.
- The sixth executive seat, if you take one: Operations Transformation,
  Estate, or AI Trust.
