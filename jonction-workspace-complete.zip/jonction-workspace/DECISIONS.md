# DECISIONS.md

Chronological record of substantive decisions, with what was rejected. Append
only; do not rewrite history. Where a decision was reversed, add a new entry
and mark the old one superseded.

---

### D1 · Architecture vocabulary — adopted published terms
**Decided.** Systems of record / engagement / action, supported by a control
plane.
**Rejected.** An earlier house framework (Truth / Agency / Surface / Policy).
**Why.** Adopting recognised industry language is an advantage in front of an
auditor or a regulator; a house framework is a liability that must be
explained every time. Three of the four terms are published vocabulary.

### D2 · "Systems of action" is not proprietary
Distributed 2025–26 coinage (Equinix, ServiceNow and others), **not** a
Gartner term. Do not present it as ours. Gartner's nearest equivalent is
"AI agent engineering platform".

### D3 · Intelligence Platform, not a new AI unit
**Decided.** The existing fourth platform is renamed and refocused; it owns
both supply and the control plane, plus adoption.
**Rejected.** Creating a Chief AI Officer or a separate AI CoE. Adoption of
the CAIO title rose steeply through 2025–26 and a meaningful share of holders
already question its permanence; a title unwound in three years is not worth
the announcement.

### D4 · AI Assurance stays in the CTOO office — CORRECTED ONCE
**Initially** placed in the office. **Laurent proposed** moving it, with
fluency, into the Intelligence Platform. **Outcome:** fluency moved; assurance
did not.
**Why.** The Intelligence Platform supplies the models, builds the runtime and
owns adoption targets. If it also owns the gate, the supplier grades its own
homework, and the gate bends first when adoption numbers are behind. FINMA
guidance asks specifically for independent review. Second-best alternative if
it must leave the office: a joint appointment with the CRO as second-line AI
risk — not into the platform.
**Also decided:** smaller and sharper — three or four people with authority
rather than six to eight. A large assurance team is a sign the gate is not
working. Split stated explicitly: platform builds and runs the harness, trace
store and provenance service; Assurance owns golden sets, criteria and verdict.

### D5 · Fluency and change sits in the Intelligence Platform
Whoever runs the surface runs adoption; separating teaching from tooling
creates a handoff with no benefit. Counterweight written in: measured on
artefacts shipped and judgment, never on seats activated.

### D6 · The binding rule — REWRITTEN after a correct challenge
**Original (wrong).** "Every system of action needs a system of record it is
not allowed to modify."
**Challenge (Laurent).** The portfolio management system disproves it — the
order chain writes positions into the IBOR, and that write *is* the record
being created.
**Two errors identified.** (a) It classified applications rather than
capabilities; a platform normally spans all three layers. (b) "Cannot write"
was shorthand for three narrower things.
**Replacement.** *Every actor writes only through the record's own contract,
only forward, and never to the rules that constrain it.*
**Consequences.** Protection tiers re-cut into five controls; IBOR and ABOR
re-tiered to contract-only and amend-restricted; mandates, product and
approved content tiered as **rules**; "agents read, humans write" softened to
"humans authorise; writes go forward". Authority belongs to the actor, not the
layer — which is a better justification for the control plane than the one it
replaced.

### D7 · Chapters — final names
Software Engineering · Business Analysis & Design · Platform & Reliability
Engineering · Data & Knowledge Engineering.
"Design" added because process and domain design, and loop specification, are
now half that craft. "Reliability" makes error budgets and on-call an
engineering practice rather than a run desk. "Knowledge" names the ontology —
a capability that is not named is not funded. Rejected: AgentOps, LLMOps
(narrower, likely to date).

### D8 · Product names live in an appendix only — CORRECTION
An earlier draft wove the seventeen products through the body of the TOM,
mixing product identity with the layer model. Reverted: the body refers to
layers, capabilities and books; Appendix E carries the product list and the
Intelligence Platform renames.

### D9 · Product ownership — about half moves to the business
Cut follows the layer model, not a headcount target. Engagement and action
products go to the business; record, platform and control-plane products stay.
Five conditions are non-negotiable: dual key, a capacity tax the PO cannot
spend (20–25%), a PO guild in the office, CTOO appointment veto, fully loaded
cost visible to the PO.
**Analysts stay in technology** — the craft is being rebuilt, PO-plus-analyst
in the business is a shadow IT department, and they are the FDE pipeline.

### D10 · Seating — business-platform squads sit with their business
Recommended over: FDEs only (safe, under-delivers); reverse embedding
(business heads will not send people to sit with IT); rotation alone (a bridge,
not a destination). Two costs accepted: information barriers on the investment
floor, designed with Compliance rather than approved after; and identity drift,
which is why chapters and the office exist.

### D11 · Gate sequencing — structure last
Visibility → Exposure → Assurance → Structure. Explicit counter-position to
peers who reorganised first and are retrofitting controls. Triggers that would
change the plan are written down in the TOM.

### D12 · Seven commitments, not six — sharpened after benchmarking
Added a stability floor to the code commitment and a seventh on cost per
resolved task. Rationale: holding headcount neutral removes the proof point
peers use, so something must carry the burden of demonstrating value.

### D13 · Headcount framing — moved and reframed
**Rejected.** Opening the town hall with "headcount is neutral". It is a
promise about something not fully controlled, it has been heard before, and it
frames the session as being about jobs before the work is described.
**Adopted.** It appears mid-deck as the answer to "where do the gains go?",
with three destinations and the line *AI is not a headcount plan, it is a
capacity plan*, plus an explicit statement of what is and is not controlled.

### D14 · Pod — pilot before renaming
Research verdict: the squad→pod rename is cosmetic unless it carries four real
changes (smaller, end-to-end ownership, explicit decision rights including
budget, registered agents with tiers). Three pilots run under the existing
name; the vocabulary changes only if the evidence earns it. Never fewer than
four people on a regulated path.

### D15 · Cap of five owned agents per pod
Not bureaucracy — the honest limit of what four to six people can supervise.
That ceiling, not model capability, is what constrains pod autonomy. Shared
platform agents do not count against it.

### D16 · Economics stated honestly
Cost per **correctly** resolved case, reported both steady-state and fully
loaded, against a baseline signed before build. Four distortions named and
banned: mix shift, ignoring supervision, ignoring quality, forgetting the tail.
Break-even volume computed before the work, not after.

### D17 · No external announcement — with one carve-out
The no-announcement rule covers programmes, not craft. Loop and graph
engineering are versioned as internal standards with named authors, and become
visible through hiring, vendor standards and supervisor conversations.

### D18 · Chairman deck — framing corrections
**Rejected.** Opening on vendor agents entering the estate. **Adopted.**
Continuity: "we are not starting an AI programme, we are industrialising one
that works" — primitives built, a third of business users already on Claude
Code, Cowork deploying.
**Then sharpened.** Slide 3 leads on the Intelligence Platform as the
pioneering element: peers buy tools and add governance afterwards; PAM is
building the layer underneath, once, for everything.
**Caution recorded.** "No asset manager has built this" is a strong claim. The
defensible version: others have built pieces — a model platform, a registry, an
evaluation practice — but nobody has published supply and control as a single
governed layer.

### D19 · Naming standard NS-1 — names are a control, not a label
**Decided.** One grammar across agents, loops, skills, plugins, tools, MCP servers,
gateway keys, golden sets, identities, repositories, branches and decision records.
The governing rule: *prefix by the axis the reader browses* — the registry is browsed
by service, so agents are domain-first; the skill palette is browsed by craft, so
skills are object-first; the cost report is browsed by team, so keys are team-first.
**Three rules are mechanically enforced,** which is the only reason the rest will still
be followed in a year: a tool whose act segment is `amend` or `write_rule` cannot enter
an allow-list without an accepted ADR naming it; an agent whose capability verb is not
on the closed list of twelve fails registration; a gateway key that does not parse into
four segments is not issued.
**Rejected.** An advisory convention with no enforcement — every firm has one and none
is followed. A free verb list — it produces `handle`, `process` and `manage`, and an
unsearchable registry within a quarter. Model or vendor names in artefact names — the
artefact outlives the model, and a rename breaks the trace history.
**Also decided.** Names are immutable after registration. A rename is a new entry plus
`superseded-by` on the old one, because traces, cost tags, evaluation history and
incident records all key on the name.

### D20 · The method ships as skills, not as a reading list
**Decided.** Twenty-one skills in a `pam-jonction` plugin for Cowork and Claude Code:
the nine loop-engineering steps, graph engineering, pod craft and the control artefacts.
Validated in the build by `build/check-skills.sh`, including against NS-1 itself.
**Why.** A standard people are told about once is a slide; a standard people can run is
an operating model. The guide and the pod manual describe a method that takes twelve
weeks and eleven artefacts, and the failure mode of every such document is that it is
read once and approximated thereafter.
**Rejected.** A single large "Jonction" skill — it would trigger on everything and help
with nothing. Skills that read or generate golden sets: no skill in the set reads one,
because the separation between the team that builds and the team that holds the measure
is what makes a passing score evidence rather than a claim.
**Deliberately not built yet.** The eval harness for the skills themselves. Worth doing
per skill, on real candidate processes, once the first pilots have produced real inputs.

### D21 · Role book and the audience decks
**Decided.** A three-page role book covering both sides of the house, and eight decks on
one shared engine: Board, firm-wide town hall, technology town hall, and one each for
Investment, Distribution, Operations, Finance and Risk.
**Why one deck per function.** The same material lands differently: Operations needs the
honest description of the day at tier 2; Finance needs the cost stack and the four
distortions, because they referee every business case; Risk needs the register and the
three places where their decision is on the critical path rather than at the end of it.
A single deck delivered five times gets discounted four times.
**Framing per audience, deliberately.** The Board deck leads on the fiduciary line and
independence; the firm-wide deck leads on *two programmes, not one*, because conflating
Cowork adoption with loop autonomy is the most common communication error at this stage.
**Superseded.** `src/decks/jonction-townhall.html` by `src/decks/townhall-technology.html`,
which carries the same material plus the standards and a Monday-morning slide. The old
file is kept, unedited, per the append-only rule. `src/decks/chairman.html` is unchanged
and still the right artefact for a one-to-one.
**Also.** The pod manual's sparse page 13 — a table row stranded alone — is closed by
keeping the "What blocks what" table whole. Page count unchanged at 31.
