# pam-jonction

The Jonction operating standard, as skills you can run in Claude Cowork and Claude Code.

Twenty-one skills covering loop engineering end to end, graph engineering, pod craft and
the control artefacts. They encode the method in the target operating model, the business
managers' guide (*Loops & Graphs*) and the pod manual, so that the standard is something
people **use** rather than something they are told about once.

## Install

Copy `skills/pam-jonction` into the plugin location for your surface, or point your
marketplace at this directory. Skills are then invoked as `pam-jonction:<skill>` —
for example `pam-jonction:loop-spec`.

## The skills

### Loop engineering — the nine steps, in order

| Skill | Step | Who leads |
|---|---|---|
| `loop-triage` | 0 · screen the candidate against the five questions | business |
| `loop-map` | 1 · map the loop as it actually is | business |
| `loop-baseline` | 2 · measure and sign the baseline | business |
| `loop-spec` | 3 · the eleven fields | business + analyst |
| `loop-classify` | 4 · act classification against the books | business + architecture |
| `goldenset-build` | 5 · design, adjudicate and freeze the golden set | business |
| `shadow-review` | 6 · the four quadrants and the divergence report | pod + business |
| `loop-graduate` | 7 · the evidence pack and the tier proposal | business |
| `loop-run` | 8 · the monthly page | business owner |
| `loop-cost` | throughout · the honest cost model | business + finance |

### Graph engineering

`entity-define` · `relationship-define`

### Pod craft

`charter-draft` · `eval-design` · `runbook-write` · `incident-record` · `adr-write` ·
`pr-check`

### Control

`registry-draft` · `name-check` · `refusal-check`

## Three things these skills will not do for you

**Decide what the rule is.** Only the business can settle that, and the moment a skill
fills an ambiguous field with an assumption is the moment a loop starts correctly
implementing something nobody wanted.

**Produce a baseline after the fact.** It cannot be reconstructed. Every skill downstream
of `loop-baseline` asks for it, and `loop-graduate` will not assemble a pack without one
signed before build began.

**See a golden set.** No skill here reads one. The set is held by AI Assurance, and the
separation is the only thing that makes a passing score evidence rather than a claim.

## House rules these skills enforce

- Nothing skips an autonomy tier, and nothing reaches tier 3 in its first year
- A tier increase and a scope widening are never proposed in the same submission
- Amend and rules acts are absent from every registry entry — if they appear, the loop
  is mis-specified
- A gateway key that does not parse into four segments is not issued
- Names are immutable after registration; a rename is a new entry plus `superseded-by`
- An intervention rate falling toward zero is a warning, not a triumph

## Owner

Office of the Chief Technology & Operations Officer. Standard NS-1 (naming) and the
role book sit alongside these skills in `src/standards/` and `src/roles/`.
