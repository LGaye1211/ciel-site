---
name: charter-draft
description: Draft or review a pod charter - dual key, members, loops owned, registered agents against the cap of five, decision rights, escalation, release approval, service levels, on-call model, capacity tax and interfaces. Use this when a pod or squad is formed or reformed, before a pilot starts, at the quarterly charter refresh, when a team is unclear who decides what, or when decision rights are being argued about in a delivery meeting. A pilot that starts without a written charter cannot be evaluated afterwards, because nobody agreed in advance what was being tested.
---

# The pod charter

One page, in the repository root, reviewed quarterly. It is the first of the five entry
conditions for a pilot, and the reason a pilot can be judged rather than merely
described.

## What a pod is, and is not

Four to six people holding one product **end to end** — definition, build, test, release
and run — with three to five registered agents as capacity. It differs from a squad in
four respects that are design choices, not properties of the word:

- it is **smaller**
- it owns **the path from intent to run** rather than a stage of it
- it holds **explicit decision rights**, including a token budget
- it carries **named agents with autonomy tiers**

Renaming a team without those four changes is fashion, and a board reads that
correctly. Until the pilots earn it, the unit is still a squad and the charter says so.

**Never fewer than four people on a regulated path.** Three-person configurations are
for internal tools with low blast radius. A team too small to sustain a rota is an
operational resilience weakness before it is an efficiency gain.

## The three structural constraints to write down

**The dual key.** The product owner holds value — what and why, and the order of the
queue. The tech lead holds correctness — how, whether it is safe to ship — and
physically holds the release key. Neither overrules the other; disagreement escalates to
the platform lead and the business head **jointly, the same day**, not into a backlog.

**The capacity tax.** Twenty to twenty-five per cent of capacity reserved for exposure,
security, upgrades and decommissioning. Set by the CTOO office; **the product owner
cannot spend it.** When it is under pressure the tech lead says so at the quarterly
review rather than quietly lending it out.

**The cap of five.** At most five *registered, pod-owned* agents. Shared platform agents
do not count against it. The cap is not bureaucracy — it is the honest limit of what
four to six people can supervise. That ceiling, not model capability, is what limits
how fast a pod can go, and making it explicit before an incident discovers it is the
whole point.

## What the pod does not own

Golden sets (AI Assurance) · models and routing (Intelligence Platform) · the primitives
and connectors it consumes · the entitlement model · the definitions in the firm graph.
**Building any of these locally is the fastest way to make a pod unsupportable.** Say so
in the charter so it is a decision rather than a drift.

## Output

```
POD CHARTER · <name> · v<n> · <date>

PRODUCT           <product> · platform <platform> · physically sits <where>
DUAL KEY          product owner <name> (value) · tech lead <name> (correctness, release key)
MEMBERS           <name, role, chapter, % allocation>
                  ... never fewer than four on a regulated path
DRAWN FROM CHAPTERS  <craft, for what defined piece of work, until when>

LOOPS OWNED       <loop> · tier <n> · business owner <name>
                  ...
REGISTERED AGENTS <n> of 5 owned · <name, tier, one line> ...
                  shared platform agents configured: <list — not against the cap>
                  <if a slot is deliberately unused, say why — it reads as judgment>

DECIDES ALONE     PO: order of work, scope, what ships when
                  TL: design, safe to ship, tier proposals, pausing a loop
                  Engineers: implementation, tool and context design, rule-before-model
                  Analyst: specification structure, what counts as checkable
ESCALATES         <what, to whom, within what time>
                  ambiguity in a business rule → back to the manager, never resolved internally

RELEASE APPROVAL  four eyes always, including on agent-authored change.
                  approver is someone who did not write the change.
SERVICE LEVELS    <per loop> · error budget <>
ON-CALL           three-line support: automation → rotation → building engineer last
                  rotation: <who, how often>
CAPACITY TAX      <%> reserved · spent this quarter on <what>
INTERFACES        <other pods, platforms, FDEs — and the mode of each>
MEASURES REPORTED delivery · loop health per loop · cost · health and hygiene
REVIEW            quarterly · next <date>
```

## Reviewing an existing charter

Four things that are wrong most often: agents listed that are actually shared platform
agents counted against the cap; a capacity tax stated but visibly spent on features; an
escalation path with no time attached; and a release approver who is the same person as
the author on agent-authored change — which is precisely where four eyes matters most.
