---
name: loop-cost
description: Build the honest cost model for a loop - the six-line cost stack, cost per correctly resolved case, payback, break-even volume - and strip the four distortions out of any comparison against the old process. Use this whenever someone builds a business case for agentic work, quotes a saving, asks what an agent costs, compares a machine against people, or proposes automating something whose volume might be too low. Use it proactively when a figure looks flattering: the difference between the quotable number and the honest one is routinely twenty points, and being corrected on it at a platform review is avoidable.
---

# The cost of a loop, honestly

A loop is not free because the work is done by a machine. It has a build cost, a run
cost and a supervision cost, and **the only number that settles an argument is cost per
correctly resolved case, against the process it replaced.**

## The six-line stack

Most business cases count only the first line of the run column. The lines beneath it
are where loops quietly stop paying.

| Line | What people miss |
|---|---|
| **Build, one-off** | Your days, the analyst's, the engineer's, **golden-set adjudication** and assurance review. Adjudication — two seniors for two to three days — is the line most often left out. Amortise over three years unless the process will change sooner. |
| **Run — agent** | Inference, retrieval, tool calls. Read from the gateway, tagged. **Per case, not per month**: a monthly total hides a rising cost per case behind falling volume. |
| **Run — human** | Review, exception handling, declined cases. Usually the largest cost after go-live, and the one that falls as the tier rises. Sample it; do not estimate. |
| **Run — platform** | Your share of gateway, registry, evaluations, observability, provenance. Small per case, and the price of not building your own plumbing. |
| **Maintenance** | Golden-set refresh, drift investigation, new patterns, upstream changes. Roughly half a day a week per live loop in year one. A loop nobody maintains is not cheap; it is unowned. |
| **Rework** | The loop's own errors, including downstream correction. **If you do not count this, the comparison is dishonest by construction.** |

## The unit, and the two variants

**Cost per correctly resolved case.** The denominator is cases resolved *and right* —
not cases touched, not cases closed.

Report both variants side by side, because they answer different questions:
- **Fully loaded** includes amortised build → was the investment worth making?
- **Steady state** excludes it → what does this process now cost to run, for next
  year's budget?

Both compare against one number: the baseline cost per case signed before anything was
built.

## Two numbers to derive once

**Payback period** = build cost ÷ net annual saving. Under twelve months is strong;
beyond twenty-four, question whether a loop is the right intervention at all.

**Break-even volume** = annual fixed cost (amortised build + platform + maintenance) ÷
saving per case. Below that volume the loop costs more than the people. **Compute it
before the work, not after** — it is the number that tells you which of your processes
should never be automated, and refusing a request with this arithmetic is the most
credible thing a delivery team does.

## The four distortions — strip these before you quote anything

| Distortion | The correction |
|---|---|
| **Mix shift** | The loop handles the routine share; its cost is compared against the human average across *all* cases including the hard ones. Compare like with like — the loop's cost on its scope against the human cost on that same scope. Report the blended figure separately. |
| **Ignoring supervision** | Agent cost counted, review time not. Human review is a run cost of the loop, not a residual of the old process, until the tier rises enough to remove it. |
| **Ignoring quality** | Cost per case falls, error rate rises, nobody nets the two. Use cost per *correctly* resolved case, with escapes counted and priced. |
| **Forgetting the tail** | The old process was slow at the median and valuable at the ninetieth percentile. A loop that halves the median and leaves the tail untouched has produced less than it appears. Report both and state which one the business feels. |

## A fair comparison states five things

The scope compared, identical on both sides · the period, including at least one
month-end · cost per correctly resolved case, both variants · the error rate **on both
sides** — the old process has one too, and it is usually higher than anyone believes ·
median and ninetieth-percentile cycle time.

## The comparison people forget to make

The old process is not static and free. It carries its own error rate, its own rework,
its own overtime at quarter-end, and the cost of knowledge walking out when someone
leaves. **A loop that merely matches human cost while making the process measurable and
transferable may still be worth having** — but say that explicitly rather than inflating
the savings to justify it.

## Quality gains: report separately, do not fold in

If mis-categorisation fell, price the correction of one and report the annual figure as
a separate line. Folding a quality gain into a cost saving is exactly the move that
gets a business case disbelieved.

## Output

Use `references/cost-stack.md` for the full worked layout, including the optimisation
levers ranked by typical effect. The first three levers — put a rule in front of the
model, narrow the scope, route by task — are worth more than everything below them
combined, and none of them involves negotiating a better rate for inference.
