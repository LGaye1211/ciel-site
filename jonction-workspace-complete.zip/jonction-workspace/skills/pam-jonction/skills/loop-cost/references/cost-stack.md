# Cost model — working layout

## Build, one-off

```
LINE                                              DAYS    CHF
Business manager — map, baseline, spec, shadow    <>      <>
Golden-set adjudication — two seniors + a third   <>      <>
Business analyst — spec, harness, divergence      <>      <>
Engineering — build, integration, instrumentation <>      <>
AI Assurance — evaluation design, gate review     <>      <>
Platform onboarding — identity, registry,
  connectors, cost tagging                        —       <>
TOTAL BUILD                                       <>      <>   amortised /3 = <>/yr
```

## Run, annual — at the month-3 run rate

```
LINE                                         PER CASE   PER YEAR
Human review and exception handling (<min>)  <>         <>
Agent — inference, retrieval, tool calls     <>         <>
Platform share                               <>         <>
Maintenance — refresh, drift, new patterns   <>         <>
Rework — escapes, priced at correction cost  <>         <>
STEADY-STATE TOTAL                           <>         <>
FULLY LOADED (incl. amortised build)         <>         <>
```

## The comparison table

```
COMPARISON                      FIGURE           COMMENT
Baseline, signed before build   CHF <>/case      <min> touch time + <%> error rate
The flattering claim            CHF <> (−<%>)    human minutes + agent cost only.
                                                 This is the number that will be
                                                 quoted at you if you do not
                                                 publish the one below.
Steady state, honest            CHF <> (−<%>)    adds platform, maintenance, rework
Fully loaded, years 1–3         CHF <> (−<%>)    adds amortised build. The business-case figure.
Like-for-like on scope          CHF <> vs <>     the automated categories only — the
                                                 only comparison undistorted by mix shift
Net annual saving               CHF <>           baseline less steady state less amortised build
Payback period                  ~<n> months      build ÷ net saving before amortisation
Break-even volume               ~<n>/year (<n>/day)  fixed cost ÷ saving per case.
                                                 Below this the loop costs more than the people.
```

Check the arithmetic is internally consistent before anyone else does:
`steady-state per case × annual volume = steady-state per year`, and
`fully loaded = steady state + (build ÷ amortisation years)`. Break-even uses the
*steady-state* saving per case; state which saving figure you used, because the fully
loaded and steady-state savings differ and the two produce different break-even points.

## Optimisation levers, ranked by typical effect

The first three are worth more than everything below them combined.

1. **Do not use a model where a rule works.** A large share of most loops is
   deterministic — a threshold, a lookup, a date comparison. A rules pre-filter in front
   routinely removes a third of volume from the paid path *and improves accuracy*,
   because rules do not vary between runs. Those cases also become trivially auditable.
2. **Narrow the scope.** The hard tail costs disproportionately — more retrieval, more
   iterations, more escalation — and is where errors concentrate. Excluding a category
   can cut cost per case materially while removing a small share of volume. Revisit
   exclusions annually, not never.
3. **Route by task, not by habit.** Classification does not need the largest model. Small
   model on the routine path; escalate only below the confidence threshold.
4. **Retrieve less, and precisely.** Cost tracks context pulled per case. A well-modelled
   graph is the main lever: traversing to three relevant facts is cheaper *and* more
   accurate than searching for them. This is where graph work pays for itself in cash.
5. **Cap iterations.** Retries and re-retrievals are where cost incidents come from. Watch
   for the pathology: if the top one per cent of cases by cost exceeds five per cent of
   spend, a cap is missing.
6. **Cache and batch.** Stable context cached; work without a deadline batched off-peak.
   Platform features you opt into; neither changes your specification.
7. **Tune the confidence threshold.** There is a genuine optimum. Too low and errors
   escape; too high and humans review cases the loop had right — the expensive failure.
   Move it in small steps against measured accuracy, monthly, and record each move.
8. **Raise the tier when evidence allows.** The largest long-run saving is removing human
   review from cases that no longer need it. This is why tiers exist and why they must
   be earned.
9. **Retire what is not used.** Every live loop carries maintenance and attention whether
   or not it is doing work.

## Graph work is costed differently

Graph cost is almost entirely people-time; compute is negligible. So:

- **Model on demand, not for completeness.** Define the entities the next two loops
  actually need. A complete model of the firm pays nothing until it is finished.
- **Measure the second-loop discount.** Build cost of loop one versus loop two versus
  loop three in the same service, with the share attributable to definitions that
  already existed. *If that curve is not falling, the graph work is not being reused* —
  which is a real finding, and usually means the entities modelled were not the ones
  the loops needed.
- **Count the avoided cost.** Graph work mostly prevents expense rather than reducing it:
  rework from wrong joins, incidents from mismatched identifiers, analyst-days spent
  reconciling two reports that should agree. Keep a simple log before and after.
