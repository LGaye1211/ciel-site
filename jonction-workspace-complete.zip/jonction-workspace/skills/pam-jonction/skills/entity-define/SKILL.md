---
name: entity-define
description: Define a business entity for the firm graph - preferred term, aliases, identity rule, conflict rule, what survives change, and authority per attribute. Use this for graph engineering steps 1-2, whenever two teams use different words for the same thing or the same word for different things, when an identifier will not join, when someone asks what a client or a break or a theme actually is, or when a data project needs definitions before it can start. Only the business can settle these; if you do not, someone less qualified will infer them from the data, and the inference will be wrong in exactly the cases with money attached.
---

# Defining an entity

Graph engineering, steps 1 and 2. Half a day to list; a day to define identity. Owned
by the business manager whose service owns the truth about the thing.

## First: which things do you actually own?

List every noun that appears in your team's conversations and that the firm would
recognise — fund, share class, mandate, portfolio, position, instrument, issuer,
counterparty, custodian, client, distributor, theme, break, document, obligation.
Twenty to forty is normal.

Then **mark the ones your service owns the truth about**. A reconciliation service does
not own "instrument"; it does own "break" — its states, its categories, its lifecycle.
Owning a thing means you are the one who settles arguments about what it is.

Define only what you own. Before defining anything, check whether another team already
owns it: **duplicate definitions are worse than none**, because they create disputes
that surface later as data errors.

## The four questions, and why only you can answer them

**What is this thing, exactly?** Is a "client" the legal entity, the mandate, or the
relationship? The firm uses all three words for all three meanings.

**How do we know two records are the same thing?** Which identifier is authoritative,
and what happens when they conflict. *This is the question that breaks most data work,
and it is a business question, not a technical one.*

**Which system is the source of truth for each attribute?** Not which system has it —
which one is *right* when they differ.

**What is the relationship, in words?** "Belongs to" hides at least four different
meanings. See `relationship-define`.

## Identity is the hard part

For each entity you own, answer four things precisely:

- **Which identifier is authoritative**, and who issues it
- **What happens when two sources disagree** — which wins, and on what grounds
- **Whether identity survives change.** If a break is re-categorised, is it the same
  break? If a share class merges, what happens to its history? This is where most
  models quietly go wrong, because the answer is usually "yes for this change, no for
  that one" and nobody writes down which is which.
- **The acceptable duplicate rate**, and how duplicates are detected

## Synonyms and homonyms — the workshop nobody enjoys

Two endemic patterns, both only resolvable by the business:

**Synonyms** — the same thing with different names across teams. A "break" may be
operations' "exception" and finance's "difference". Pick one preferred term, record the
others as aliases, and stop arguing.

**Homonyms** — the same word for different things. "Client" is the most dangerous in an
asset manager: to distribution it is often the distributor, to operations the legal
entity, to reporting the mandate. **Each meaning gets its own name.**

Run the workshop with peers in the room rather than juniors, and record decisions the
same day. It is uncomfortable because it exposes that teams have been talking past each
other for years. Run it anyway — that is the finding.

## Output

```
ENTITY            <preferred term, singular, lowercase>
OWNED BY          <service> · settles disputes: <named manager>
ALIASES           <terms other teams use, with the team against each>
HOMONYMS SPLIT    <if the word carried more than one meaning, the new names now in force>

DEFINITION        One paragraph, plain language. Written so that someone in another
                  function could apply it to a case they had never seen.

IDENTITY RULE     A <entity> is identified by <attributes>.
AUTHORITATIVE ID  <identifier> · issued by <who>
CONFLICT RULE     When <source A> and <source B> disagree, <which wins>, because <grounds>.
SURVIVES CHANGE   Survives: <which changes preserve identity, with history retained>
                  Does not survive: <which changes create a new instance, and what
                  happens to the old one>
DUPLICATE RATE    target below <%> · detected by <method>

AUTHORITY MAP     <attribute> → authoritative book <x>; other copies: <cache | derived | copy>
                  ... one line per attribute that matters

DECIDED           <date> · Architecture Board reference <if disputed>
```

## Why the authority map matters more than it looks

It is what lets provenance work. When a figure reaches a client it carries source,
snapshot time and version — and "source" is only meaningful if it was **decided in
advance** rather than inferred afterwards.

## Maintain it

A day a month. Review new entities your service started talking about, definitions that
turned out to be wrong, and relationships that changed because a product or market
convention changed. Disputes go to the Architecture Board, which has a permanent seat
for Data & Knowledge Engineering and closes them within a month, on the record, with a
date — rather than leaving them to whoever documents it last.

## The payoff, stated honestly

Graph work pays back slowly and then suddenly. The first six months produce definitions
and arguments. After that every loop you specify becomes cheaper, because the meanings
it depends on already exist. The number that proves it: build cost of loop one versus
loop two versus loop three in the same service.
