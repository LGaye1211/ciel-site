---
name: loop-classify
description: Classify every step of a loop against the five act categories - read, propose, write forward, amend, touch rules - and derive the controls that follow. Use this at step 4 of loop engineering, whenever someone asks what an agent is allowed to do to a system, is preparing for the Architecture Board, is designing permissions or a tool allow-list, or is unsure whether a step counts as a write. Use it as a review tool too: a step that lands in the amend or rules category means the loop is mis-specified, and catching that before build is worth far more than catching it at the gate.
---

# Classifying acts against the books

Step 4 of nine. Week four. Business manager with architecture. **This determines the
controls and is not negotiable afterwards** — which is why it goes to the Architecture
Board rather than being decided inside the delivery team.

## The binding rule this implements

> Every actor writes only through the record's own contract, only forward, and never to
> the rules that constrain it.

Three separate things: writes take the authorised path; originating forward is normal
while retroactive amendment is a human-approved act; and no actor changes the rules it
is judged by. The five categories below are that rule made operational.

## The five categories

| Act | What it is | Control that follows |
|---|---|---|
| **Read** | Reads a book of record or reference data. | Entitlements propagate to the requesting human. Never a service account. Every read logged with purpose. |
| **Propose** | Produces a recommendation a human accepts or rejects. | No control beyond evaluation. **The safest category, and where every loop starts.** |
| **Write forward** | Originates a new record through the system's own authorised path — an instruction, an allocation, a case closure, a message to a counterparty. | Permitted within stated limits. Through the record's own contract with attribution to the agent identity; never direct to the store. |
| **Amend** | Changes an existing record retroactively — a correction, an adjustment, a restatement. | Human-approved, always, through maker-checker. **This is where error and fraud concentrate.** |
| **Touch rules** | Would change a mandate, fee schedule, security master, settlement instruction, theme criterion or approved content. | **Forbidden.** No loop writes to the rules it is judged by. |

## Two judgments people get wrong

**"It only writes to our own case system, so it isn't really a write."** It is a write
forward. It needs the authorised path, attribution to the agent's own identity, and an
entry in the registry naming the book and the act. The fact that the record is yours
changes who owns it, not what class of act it is.

**"Sending a message isn't a write."** Sending to a counterparty — a chase, an
instruction, a confirmation — is a write forward with an *external* blast radius, which
is usually the largest one in the loop. It needs its own evidence and usually its own
loop, graduated separately.

## If a step lands in "touch rules", the loop is mis-specified

Do not design around it. Split it: **the loop proposes a rule change in a report, and a
human makes it.** This is a clean, common and entirely acceptable pattern — the loop
that notices the taxonomy is wrong is doing something valuable, and it does it by
writing a report rather than by editing the taxonomy.

## If a step lands in "amend", take it out of the loop

Corrections go through the existing maker-checker chain, performed by a human. The loop
may prepare the correction, present the evidence and draft the request. It does not
execute it, and it does not correct its own mistakes.

## Output

An annotated specification where every step carries exactly one label, plus the
derived control list. Take this to the Architecture Board with the entitlement model
and the connector list.

```
ACT CLASSIFICATION · <loop name> · <date>

STEP                                  ACT            CONTROL IMPLICATION
<step, in the words of the spec>      read           entitlements propagate to <who>; logged with purpose
<step>                                propose        nothing acts on it at tier 1
<step>                                write forward  via <system> API, attributed to <agent identity>
<step>                                amend          EXCLUDED — human maker-checker
<step>                                rules          FORBIDDEN — loop proposes in a report; human decides

BOOKS TOUCHED    <book> (<act>) · <book> (<act>) ...
TOOL ALLOW-LIST  <tool names, per the naming standard>
                 any tool whose act segment is amend or write_rule requires an
                 accepted architecture decision record naming it
EXCLUSIONS       what was deliberately taken out of the loop, and why
REVIEWED         Architecture Board, <date>
```

## How this connects to everything else

- The **registry entry** (`registry-draft`) carries `books touched` with the act against
  each. Amend and rules must be absent.
- The **tool allow-list** is derived from this table and enforced at the gateway.
  Anything absent is unavailable, not merely discouraged.
- The **naming standard** puts the act into the tool name — `ibor.read_position`,
  `casesys.write_forward_classification` — so that a reviewer can read an allow-list
  without opening a single definition, and so a CI check can block a dangerous act by
  name. Run `name-check` on the allow-list before the board.
