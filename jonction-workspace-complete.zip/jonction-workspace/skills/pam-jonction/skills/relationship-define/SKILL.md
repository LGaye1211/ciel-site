---
name: relationship-define
description: Write the relationships between business entities as checkable statements with direction, cardinality, time-dependence and authority. Use this for graph engineering step 3, whenever a data model uses "belongs to" or "relates to", when counts from two systems disagree, when a join produces the wrong number of rows, or when someone needs to model how funds, mandates, positions, themes and clients actually connect. Relationships carry more meaning than entities and are usually left vague, so raise this even when the entity definitions look finished.
---

# Naming relationships in words

Graph engineering, step 3. Half a day. Owned by the business.

Relationships carry more meaning than entities and are the part most often left vague.
Write each one as a **sentence**, then interrogate the verb.

## Ban two phrases for the duration

**"Belongs to"** and **"relates to"** are forbidden during this exercise. They hide the
distinctions that matter, and they are how a model passes review while meaning nothing.
If the only verb you can find is one of those two, the relationship has not been
understood yet.

## Four properties, every time

**Direction.** Which way does it run, and does the reverse mean the same thing? *A fund
is governed by a mandate* is not the same statement as *a mandate governs a fund* once
you ask which one can exist without the other.

**Cardinality.** One to one, one to many, many to many? Get this wrong and every
downstream count is wrong — and the error surfaces as a reconciliation break months
later, not as a modelling complaint.

**Time.** Does it hold *as of* a date? **Most relationships in an asset manager do, and
forgetting this is the single most common modelling error.** A portfolio holds a
position as of a date. An issuer qualifies for a theme under criteria that changed in
March. A document is approved for a jurisdiction until it is superseded. A model without
time produces answers that are correct for today and wrong for every question about
last quarter.

**Authority.** Which system is right about this relationship when systems disagree?
Distinct from which system is right about the *entities* at either end.

## Output

One line per relationship, in this shape:

```
STATEMENT     A <entity> <verb> <entity>, <qualifier>.
DIRECTION     <which way> · reverse reads as: <...> · same meaning? yes/no
CARDINALITY   <1:1 | 1:n | n:n>  ← state which side is which
TIME          as-of: yes/no · <what changes when it changes> · history retained? yes/no
AUTHORITY     <system> is authoritative; <others> are <copies | derived views>
```

Worked examples, in the house style:

```
A break compares a custodian record to a book record, for one portfolio, as of one date.
  direction n/a (symmetric in form, not in authority) · cardinality many-to-one on portfolio
  time as-of the value date · authority: neither side is authoritative for the other,
  which is the entire point of the service

A break is categorised as exactly one category, as of a timestamp, with history retained.
  cardinality 1:1 at a point in time, 1:n over the life of the break
  time as-of · re-categorisation preserves identity (see the entity's survives-change rule)

A break may be explained by zero or more corporate actions.
  cardinality n:n · time as-of the action's ex-date, not its capture date
  authority: reference data

A chase is addressed to one custodian and concerns one or more breaks.
  cardinality 1:n · time none · authority: the case system
```

## Two tests before you call it done

**The counting test.** Pick the relationship and ask: if I counted along it, what would
the number mean? If two reasonable people would count differently, the cardinality or
the time-dependence is still unstated.

**The disagreement test.** Name the system that would disagree with this statement
today. If none would, the relationship is probably too vague to be wrong — which means
it is too vague to be useful.

## Then

These statements are the input to `entity-define`'s authority map, and they are what
lets a loop **traverse to a fact rather than search for it**. That traversal is
simultaneously the largest cost lever and the largest accuracy lever available to a
pod, which is why this half-day is worth protecting.
