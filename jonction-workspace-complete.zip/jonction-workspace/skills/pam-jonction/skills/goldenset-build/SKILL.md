---
name: goldenset-build
description: Design, stratify, adjudicate and freeze a golden set - past cases with the correct answer and the reasoning attached. Use this at step 5 of loop engineering, whenever someone needs evaluation data or test cases for agentic work, asks how to prove an agent is right, wants to validate an AI against expert judgment, or proposes validating as they go. This is the single most valuable artefact in the method and the one most often skimped, so push for it early and hard - a project that reaches week seven without a frozen golden set does not recover.
---

# Building the golden set

Step 5 of nine. Weeks four to six — and the heaviest weeks of the business's
involvement. Owned by the business, frozen and held by AI Assurance.

## What it is

A collection of past cases with the correct answer attached **and the reasoning
recorded**. Not a test set in the software sense: a written record of how expert
judgment is actually exercised in this service, which is why it has value far beyond
the loop it was built for.

## Design

**Size.** Two hundred cases minimum for a first loop; four hundred if there are more
than four end states. Enough that every end state has at least thirty examples — a
category with five examples produces a score that means nothing.

**Sampling — the part that goes wrong.** Not the last two hundred cases. That
over-represents whatever was happening last month and under-represents everything the
loop will find hard. Instead:

- Stratify proportionally across end states
- Deliberately **over-sample the rare and hard categories**
- Include at least twenty cases the team originally got wrong and later corrected —
  these matter more than the clean ones, because they mark where the process itself
  fails
- Include a dozen **negative controls**: cases that are out of scope, so the evaluation
  confirms the loop *declines* what it should decline. A pass here is as important as
  accuracy, and almost nobody includes them.

## Adjudication

Two experienced people answer each case **independently**. Where they disagree, a third
settles it and the disagreement is recorded. Those disputed cases are the most
informative in the whole set, because they mark the genuine boundary of the rule.

One line per case on *why*. This is what turns a dataset into institutional knowledge,
and it is what a junior will later learn the craft from.

Budget: two seniors for two to three days, plus a third on disputes. **Book the time in
week one.** The week that slips is always week five, because the best adjudicators are
the busiest people.

## Expect the uncomfortable finding, and frame it in advance

Teams frequently discover their own experts agree only about eighty per cent of the
time. Say before you start that this is likely, so that when it happens it reads as the
exercise working rather than as a problem.

It is not a reason to stop. It is the most useful thing the exercise produces, and it
should be **fixed with a clarified written rule before any evaluation runs**. That rule
change often removes a recurring source of error from the existing manual process and
is arguably worth more than the loop.

## Freezing — and why the pod never sees it

Once built, the set is frozen and held by AI Assurance. **It is never shown to the
people tuning the loop.** That is the whole point: a team that can see the measure will
optimise for it, without meaning to and often without noticing. The separation is the
only thing that makes a passing score evidence rather than a claim, and it is what lets
a tech lead defend a release to an auditor with a straight face.

The pod works against forty or so development examples it holds and may freely inspect.
Those are a different thing and must never be called the golden set.

Refresh quarterly: a few dozen recent cases replace the oldest. Production failures are
added to the set by Assurance — that is the only route by which a real-world failure
reaches the evaluation.

## Output

```
GOLDEN SET        gs-<loop>-v<n>
SIZE              <n> cases, drawn across <period>
STRATIFICATION    <end state>: <n> ... (one line each, summing to size)
OVER-SAMPLED      <which rare categories, and why>
DELIBERATE INCLUSIONS
  <n> cases the team originally got wrong and later corrected
  <n> negative controls from out-of-scope categories
  all known exception patterns, in proportion
ADJUDICATION      <n> adjudicators, independently, <n> days; disputes settled by <role>
INITIAL AGREEMENT <%>  ← record this; it is a finding about the process, not the set
DISAGREEMENT PATTERNS
  <each one, and the written rule change that resolved it>
FROZEN            <date> · held by AI Assurance · refresh: <n> cases quarterly
```

## Refuse to proceed without it

No shadow run begins without a frozen set. The alternative — "we'll validate as we go" —
produces an argument about anecdotes at the graduation board, and a demonstration that
impresses people and proves nothing.

## Then

`eval-design` for the pod's side of the harness, then `shadow-review` at step 6.
