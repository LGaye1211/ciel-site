---
name: adr-write
description: Write an architecture decision record - context, options considered including the one not taken, the decision, consequences including what becomes harder, and the act and book implications. Use this whenever a design decision constrains future work, when a tool touching amend or rules is proposed for an allow-list, when a choice is being re-litigated because nobody wrote down why it was made, or before the Architecture Board on anything cross-product. Records are append-only and are never edited after acceptance, so use this to write the decision properly the first time.
---

# Architecture decision records

Append-only, never edited after acceptance. Where a decision is reversed, a **new**
record supersedes the old one and the old one stays.

The reason for append-only is not tidiness. A decision record's value is almost entirely
in the *rejected options* and in what the decision made harder — and both of those get
quietly deleted by anyone editing the record later to reflect what they now believe.

## When one is required

- Any decision that constrains work beyond the product it was made in
- **Any tool whose act segment is `amend` or `write_rule` entering an allow-list.** The
  naming standard makes these visible in the tool name precisely so that this
  requirement can be enforced mechanically rather than remembered.
- Any new class of act against a book of record
- Any breaking change to a data contract
- Any decision you can imagine being re-argued in a year — which is most of the
  interesting ones

## Writing the parts well

**Context.** What *forced* the decision. Not background: the specific pressure that made
doing nothing unacceptable. If you cannot name it, the decision may not be needed.

**Options considered.** Including the one not taken, with the honest reason. This is the
part that earns the record its keep. An options list with one plausible entry and two
strawmen is worse than no record, because it invites exactly the re-litigation it was
meant to prevent.

**Decision.** One paragraph. Active voice, in the present tense.

**Consequences — including what becomes harder.** Almost every record states the
benefits and omits the costs, which is how a firm accumulates decisions nobody would
make again. Name at least one thing this makes harder, and be specific.

**Act and book implications.** If it changes what is touched or how — which book, which
act, which control now applies. This is the field the Architecture Board reads first.

## Output

```
ADR-<nnnn> · <title>
STATUS        proposed | accepted | superseded by ADR-<nnnn>
DATE          <date>        AUTHOR <name>

CONTEXT
  What forced this decision. One paragraph.

OPTIONS CONSIDERED
  A · <option> — <why not, honestly>
  B · <option> — <why not>
  C · <chosen>  — <why>

DECISION
  <One paragraph, present tense, active voice.>

CONSEQUENCES
  Enables: <...>
  Becomes harder: <...>          ← required, and be specific
  Costs accepted: <...>

ACT AND BOOK IMPLICATIONS
  Books touched: <book> (<act>) ...
  Controls now applying: <...>
  Tool allow-list change: <...>  ← if this admits an amend or write_rule tool,
                                    say so explicitly; that is why this record exists

REVIEWED BY   <Architecture Board, date — where cross-product>
```

## Numbering and naming

`adr-<nnnn>-<slug>`, four digits, zero-padded, in the repository's `adr/` directory.
The number is allocated when the record is written, not when it is accepted — a
proposed record that is rejected keeps its number and stays, because "we considered this
and said no" is worth as much as a yes.
