---
name: incident-record
description: Record and work an incident where the actor was an agent - contain, establish scope from registry and traces, explain from stored evidence, correct through maker-checker, learn by routing failures to the golden set, report. Use this during or immediately after any agent incident: a wrong action, a drift alert, a cost anomaly, a connector or schema failure. Use it also when someone asks why an agent did something, because "why did it do that" must be answerable from the trace rather than by asking the model, and an incident that cannot be explained cannot be closed.
---

# Incident practice when the actor is an agent

The shape is familiar. Six things differ, and each of them differs for a reason worth
stating.

## Contain

**Pause the loop first, investigate second.** Pausing is cheap and reversible; a running
loop makes more of whatever it is doing wrong. This is the opposite of the instinct a
deterministic outage trains.

## Establish scope

Query the **registry and the traces** for every case the loop touched in the window.
Flag every case acted on at tier 2 or above for human re-review.

This is why replay and tracing are mandatory rather than nice to have: without them the
scope of an incident is a guess, and a guess is not something you can put in front of a
supervisor.

## Explain

**Reconstruct the reasoning from the trace, not from the model.** Asking the model why
it did something produces a plausible answer that is not evidence. "Why did it do that"
must be answerable from stored evidence — inputs, retrievals, tool calls, the version of
the context and the model pin at the time.

If it cannot be answered from the trace, that gap is itself a finding and belongs in the
record.

## Correct

Corrections to books go through **the normal human maker-checker chain.** The loop does
not fix its own amendments. A loop that corrects its own errors is writing retroactively
to a record, which is the one act the model forbids it — and the temptation is strongest
precisely when everyone is under pressure.

## Learn

Failing cases go to **AI Assurance for golden-set inclusion.** That is the only route by
which a production failure reaches the evaluation, and it is what stops the same failure
recurring silently.

**The runbook is updated before the incident is closed.** No exceptions. This is the
discipline that makes the second occurrence cheaper than the first.

## Report

Business owner immediately for anything in their service. Monthly **Responsible AI
forum** for anything client-facing or any autonomy question.

## Output

```
INCIDENT RECORD · <loop> · <window>

CLASS             wrong action | drift | cost | tool or source failure
DETECTED BY       <alert / sample review / downstream / a person>
                  <if a person found it before the alert did, say so — that is a
                   finding about the monitoring, not a detail>
TIME TO CONTAIN   <from detection to pause>

CASES TOUCHED     <n>, from registry and traces
CASES ACTED ON    <n>, of which <n> required human re-review
                  <n> found to be wrong · <n> confirmed correct

EXPLANATION       Reconstructed from traces: <what actually happened>
                  Model pin at the time <> · context version <>
                  <if the trace could not explain it, say so plainly and raise it>

CORRECTIONS       <n> through maker-checker, by <who>, completed <when>
                  The loop corrected nothing itself.

CASES TO ASSURANCE  <n>, for golden-set inclusion
RUNBOOK UPDATED   <what changed> · before closure: yes
SPECIFICATION     <did a field turn out to be wrong? which?>

REPORTED TO       business owner <name> <when>
                  Responsible AI forum <date, if client-facing or autonomy-related>

RESUMED           progressive: <slice> <date> → <n>% <date> → full <date>
```

## Two questions worth asking every time

**Would the runbook's diagnosis order have found this?** If the true cause was fourth on
the list, reorder it. The list is meant to encode experience, and this is the moment
experience arrives.

**Did anything about the loop's own measurement fail?** A wrong action that the
evaluation did not catch says something about the golden set, not only about the loop.
That belongs in the record and goes to Assurance with the failing cases.
