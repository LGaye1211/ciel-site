---
name: loop-spec
description: Write the eleven-field loop specification - trigger, scope, inputs, rules, iteration budget, stopping condition, confidence threshold, human checkpoint, blast radius, cost ceiling, escalation. Use this at step 3 of loop engineering, whenever someone needs to define precisely what an agent may attempt and how a reviewer will judge it, is writing requirements for agentic work, asks how to specify an agent, or hands over a process document expecting it to serve as a specification. Use it too when reviewing someone else's specification for gaps - an unfilled field is a question for the business, never an assumption to fill in.
---

# Writing the loop specification

Step 3 of nine. Weeks three to four. The business manager owns the content; a business
analyst owns the form. This is the artefact everything else references.

## What makes it a specification rather than a procedure

A procedure tells a person what to do. A specification tells a machine what it may
attempt and tells a reviewer how to judge whether it succeeded. The difference is that
**every field has to be checkable.**

The working standard: a specification is complete when an agent can act on it, an
engineer can challenge it, a test suite can validate it and a reviewer can judge it —
without a follow-up conversation. Ambiguity travels faster in an agentic flow and does
more damage, because a vague requirement produces plausible, wrong tickets, tests and
code before anyone notices.

## The eleven fields

**1 · Trigger.** Precisely what starts one instance. *"A break record is created on the
exception queue by the overnight match run, for a portfolio in the in-scope list"* is a
trigger. *"When there's a mismatch"* is not.

**2 · Scope — in and out.** Which cases are in, which are explicitly out. The hard
requirement: **out-of-scope cases must be recognisable at the trigger**, from fields
already present, not discovered halfway through. If a case can only be identified as
out of scope after three retrievals, the exclusion is not an exclusion — it is an
expensive failure path.

**3 · Inputs.** Every source of evidence, named by system, with the entitlements needed
to read it. Entitlements propagate to the requesting human. No service accounts.

**4 · Rules it is judged against.** The criteria and where they live — a taxonomy, a
convention table, materiality thresholds, a mandate. Critically: **the loop may read
these and may never write them.** State that explicitly in the field; it is the third
clause of the binding rule and the thing an auditor will look for.

**5 · Iteration budget.** How many retrievals, retries or chases before it stops.
Unbounded loops are how cost incidents happen — a small share of cases quietly consumes
a large share of spend. A typical cap: six retrievals, two retries, then stop and mark
the case unhandled.

**6 · Stopping condition.** What "done" means for each end state, in checkable terms.
Include the negative outcome as a valid, countable one: *"unclassified"* is a result,
not a failure, and counting it is how you detect drift early.

**7 · Confidence threshold.** Below what level of certainty it hands over instead of
acting, and what it hands over with. Reviewed monthly against observed accuracy.

**8 · Human checkpoint.** Where a person sits — before action, on a sample, or on
exception only. Write it *per autonomy tier*, because this field is what actually
changes when a tier is granted.

**9 · Blast radius.** The worst thing one instance can do if it goes wrong, **expressed
in units of the business**: cases, francs, clients, days. Not "a bad classification" —
*"a material item is mis-categorised as transient and ages an extra two days, bounded
by the aged-item report, which is human-reviewed daily."* Naming the compensating
control is part of the field.

**10 · Cost ceiling.** Per instance and per day, above which the loop stops and alerts.

**11 · Escalation.** Who is called, within what time, with what information. Name a
role and a number of minutes, and state the automatic pause condition.

## Two fields people get wrong

**Blast radius** is written as a technical statement when it needs to be a business
one. The test: could the business owner read it and decide whether they accept it?

**Rules** is left as a system name when it needs to name the *artefact* and assert the
non-write. If this field is vague, the act classification in `loop-classify` will fail.

## Gaps go back, they do not get filled

An unanswered field is a question for the business, named and returned. Filling it with
an assumption is how a loop ends up correctly implementing something nobody wanted.
This is the analyst's job and it should not reach the tech lead.

## Output

Use the template in `references/spec-template.md` — it is the same form the graduation
board expects and the pod stores beside the code. Version it; changes to the
specification are changes to the loop, and travel in the same pull request as the
behaviour they describe.

## Completeness check

Before calling it done:

- [ ] All eleven fields filled with checkable statements
- [ ] Out-of-scope cases recognisable at the trigger
- [ ] The rules field asserts that the loop never writes them
- [ ] Blast radius stated in business units, with its compensating control
- [ ] Cost ceilings per instance *and* per day
- [ ] Escalation names a person and a time
- [ ] Business owner and technical owner both named individuals

## Then

`loop-classify` — every step gets one of five act labels, and that review goes to the
Architecture Board.
