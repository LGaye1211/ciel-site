# Loop specification — template

Copy this whole block. Keep the field names exactly; the graduation board, the registry
and the evaluation harness all key on them.

```
LOOP NAME            <domain>-l<n>-<slug>        e.g. recon-l1-classify-pair
SERVICE AND PRODUCT  <service> · <product home>
VERSION AND DATE     v0.1 · <date>

TRIGGER
  What exactly starts one instance. One sentence, checkable.

SCOPE — IN
  The cases this loop handles.

SCOPE — OUT
  The cases it does not. Each must be identifiable at the trigger, from fields
  already on the triggering record. State which field identifies each exclusion.

INPUTS
  <system> · <what is read> · <entitlement basis>
  ... one line per source. Entitlements propagate to the requesting human.
  No service accounts. Where the loop runs unattended, name the scoped identity.

RULES JUDGED AGAINST
  <artefact> · <where it lives> · <who owns it>
  The loop reads all of these and writes none of them.

ITERATION BUDGET
  Maximum <n> retrievals per case; maximum <n> re-attempts on source failure;
  then stop and mark <terminal state>.

STOPPING CONDITION
  Per end state, in checkable terms. Include the declined / unhandled outcome as
  a valid countable result.

CONFIDENCE THRESHOLD
  Below <x>, route to a person with the evidence attached and no answer proposed.
  Reviewed monthly against observed accuracy. Record every move.

HUMAN CHECKPOINT
  Tier 1: <...>
  Tier 2: <...>   which categories act, which always propose, what sample is reviewed
  Tier 3: <...>

BLAST RADIUS
  Worst realistic case for one instance, in business units.
  Compensating control: <what bounds it, and who reviews that control>

COST CEILING
  <CHF> per case · <CHF> per day. Breach stops the loop and alerts
  agent operations and the business owner.

ESCALATION
  Condition: <...>  → pages <role> within <n> minutes
  Business owner informed <when>. Automatic pause on <condition>.

ACT CLASSIFICATION
  Every step labelled read / propose / write forward / amend / rules.
  (see loop-classify — reviewed at the Architecture Board)

BUSINESS OWNER       <named individual> — accepts residual risk, attests annually
TECHNICAL OWNER      <named individual>
```

## Version discipline

The specification lives in the repository, versioned with the code, and changes in the
same pull request as the behaviour it describes. A specification in a document store
drifts from the system within a month and is worse than none, because people trust it.
