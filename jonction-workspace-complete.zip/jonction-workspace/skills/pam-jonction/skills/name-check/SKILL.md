---
name: name-check
description: Check a proposed name against the Jonction naming standard and return a verdict, the rule cited and a compliant alternative - for agents, loops, skills, plugins, tools, MCP servers, gateway keys, golden sets, identities, repositories, branches, decision records and graph entities. Use this before registering any agent, issuing any gateway key, creating a repository or plugin, adding a tool to an allow-list, or whenever someone proposes a name for anything that will end up in the registry. Names are immutable after registration, so checking costs a minute and renaming costs the trace history.
---

# Checking a name

Names are a control, not a label. A registry of several hundred entries is read almost
entirely by people who built none of them, and most of them stop at the name.

**Names are immutable after registration** — traces, cost tags, evaluation history and
incident records all key on them. A rename is a new entry plus `superseded-by` on the
old one. So the minute spent here is cheap.

## The one rule everything follows

**Prefix by the axis the reader browses.** The registry is browsed by service, so agents
and loops are domain-first. The skill palette is browsed by craft, so skills are
object-first. The cost report is browsed by team, so gateway keys are team-first.

## How to check

1. Identify what kind of artefact it is.
2. Match it against the form in `references/patterns.md` — that file carries every
   pattern, its regular expression, and worked examples.
3. Check it against the universal rules and the banned tokens below.
4. Return a verdict. **If it fails, always supply a compliant alternative** — a verdict
   with no alternative gets ignored and the bad name ships.

## Universal rules

Lowercase ASCII, digits and hyphens · three to forty characters · singular nouns ·
**no version, date or person in the name** (version, tier, owner and model pin are
fields) · no spaces, capitals, accents, or underscores outside a tool's act segment.

## Banned tokens, and why

| Never appears | Because |
|---|---|
| `claude` `gpt` `opus` `sonnet` `llm` `anthropic` `openai` `gemini` | The artefact outlives the model. The model is a pinned field with an evaluated upgrade path; in the name, every routine upgrade becomes a rename and every rename breaks the trace history. |
| `ai` `bot` `smart` `intelligent` `auto` `copilot` `assistant` `agentic` | Names the fashion, not the work. `recon-ai-tool` will tell a reader nothing in two years; `recon-classify-break` still tells them everything. |
| `new` `next` `v2` `final` `latest` `temp` `test` `poc` `pilot` `phase1` | Every one becomes permanent. The firm is still running systems called *new*. |
| `manage` `handle` `process` `support` `service` `solution` `engine` `framework` `platform` — as the only distinguishing word | Placeholders for a verb nobody was willing to choose. If the honest verb is not on the closed list, that is a specification problem surfacing early, which is the cheapest place to find it. |
| personal names · team names · project codenames · room names | All four change, and none is legible to an auditor or to whoever inherits the entry. |
| `jonction` | The programme name inside an artefact name dates the artefact to the programme. One deliberate exception: the `pam-jonction` plugin, which *is* the standard rather than an application of it. |

## The closed capability verb list — twelve, and only twelve

`classify` `extract` `assemble` `match` `screen` `draft` `chase` `check` `reconcile`
`remediate` `watch` `triage`

An agent whose verb is not on this list **fails registration**. The person naming it
either picks the verb that is true, or takes the case to the Architecture Board. Either
outcome beats `recon-process-items`, which is what appears when nobody is asked.

Act verbs are a different list and appear in **tool** names only:
`read` `propose` `write_forward` `amend` `write_rule`.

## Naming as a control — three enforced rules

1. A tool whose act segment is `amend` or `write_rule` **cannot enter an allow-list**
   without an accepted architecture decision record naming it. The check reads the
   *name*, so it cannot be defeated by a wrapper with a friendly description.
2. An agent with an off-list capability verb fails registration.
3. A gateway key that does not parse into four segments **is not issued**. Tagging
   cannot be retrofitted; untagged spend is unattributable for ever, and the seventh
   commitment depends on this one line.

## Output

```
PROPOSED     <name>
ARTEFACT     <agent | loop | skill | plugin | tool | mcp server | key | golden set |
              identity | repo | branch | adr | runbook | data contract | entity>
VERDICT      pass | fail
RULE         <the specific rule, quoted>
WHY          <one sentence — what a reader would be unable to tell from this name>
COMPLIANT    <a name that passes>   ← always supply one
NOTE         <e.g. this tool's act segment requires an ADR before allow-listing>
```

## Examples

```
recon-classify-break          pass
recon-ai-classifier           fail · banned token "ai" · → recon-classify-break
recon-process-items           fail · "process" is not on the closed verb list · → recon-triage-item
claude-recon-helper           fail · model name · → recon-assemble-evidence
recon.prod.l1-classify.t2     pass
recon-prod                    fail · a key needs four segments · → recon.prod.l1-classify.t2
abor.amend_entry              pass, but requires an accepted ADR before allow-listing
gs-recon-l1-v3                pass  (version belongs in a golden-set name — the set is
                                     the versioned artefact, unlike an agent)
breaks                        fail · entities are singular · → break
```
