# Naming patterns and regular expressions

Segment alphabet unless stated: `[a-z0-9]+` joined by `-`.

| Artefact | Form | Pattern | Example |
|---|---|---|---|
| Domain code | registered list, held by the CTOO office | `^[a-z][a-z0-9]{2,15}$` | `recon` `kyc` `fundcontent` `perf` |
| Loop | `<domain>-l<n>-<slug>` | `^[a-z0-9]+-l[0-9]+(-[a-z0-9]+)+$` | `recon-l1-classify-pair` |
| Pod-owned agent | `<domain>-<verb>-<object>[-<qualifier>]` | `^[a-z0-9]+-(classify\|extract\|assemble\|match\|screen\|draft\|chase\|check\|reconcile\|remediate\|watch\|triage)(-[a-z0-9]+)+$` | `recon-classify-break` |
| Platform-shared agent | `shared-<verb>-<object>` | `^shared-(…verb…)(-[a-z0-9]+)+$` | `shared-draft-test` |
| Non-human identity | `svc-<agent>-<lane>` | `^svc-[a-z0-9-]+-(build\|eval\|shadow\|prod\|explore)$` | `svc-recon-classify-break-prod` |
| Skill | `<object>-<action>` | `^[a-z0-9]+(-[a-z0-9]+){1,2}$` | `loop-spec` `goldenset-build` |
| Plugin | `pam-<standard-or-domain>` | `^pam-[a-z0-9]+(-[a-z0-9]+)?$` | `pam-jonction` `pam-recon` |
| Skill, qualified | `<plugin>:<skill>` | `^pam-[a-z0-9-]+:[a-z0-9-]+$` | `pam-jonction:loop-spec` |
| Tool | `<system>.<act>_<object>` | `^[a-z0-9]+\.(read\|propose\|write_forward\|amend\|write_rule)_[a-z0-9_]+$` | `ibor.read_position` |
| MCP server | `mcp-<system>[-<scope>]` | `^mcp-[a-z0-9]+(-[a-z0-9]+)?$` | `mcp-snowflake-recon` |
| Data contract | `dc-<system>-<dataset>` | `^dc-[a-z0-9]+-[a-z0-9]+$` | `dc-statementstore-position` |
| Gateway key / cost tag | `<team>.<lane>.<usecase>.<tier>` | `^[a-z0-9]+\.(build\|eval\|shadow\|prod\|explore)\.[a-z0-9-]+\.(t[0-4]\|na)$` | `recon.prod.l1-classify.t2` |
| Golden set | `gs-<loop>-v<n>` | `^gs-[a-z0-9-]+-v[0-9]+$` | `gs-recon-l1-v3` |
| Evaluation suite | `ev-<loop>-<layer>` | `^ev-[a-z0-9-]+-(unit\|dev\|gold\|online)$` | `ev-recon-l1-gold` |
| Repository | `<domain>` | `^[a-z][a-z0-9-]{2,30}$` | `recon` |
| Branch | `<class>/<slug>` | `^(loop\|fix\|spec\|ctx\|eval\|ops)/[a-z0-9-]+$` | `ctx/prefilter-corpact` |
| Decision record | `adr-<nnnn>-<slug>` | `^adr-[0-9]{4}-[a-z0-9-]+$` | `adr-0007-exclude-otc` |
| Runbook | `runbook-<loop>` | `^runbook-[a-z0-9-]+$` | `runbook-recon-l1` |
| Graph entity | preferred term, singular | `^[a-z][a-z0-9]*$` | `break` |

## Lanes

`build` · `eval` · `shadow` · `prod` · `explore`

A lane says *why the traffic exists*. It is what lets the quarterly review separate the
cost of running loops from the cost of building the next ones — the most common question
at a platform review and one most firms cannot answer.

## Tiers

`t0` `t1` `t2` `t3` `t4` — the autonomy tier of the loop the traffic belongs to.
`na` — traffic that is not a loop: a builder experimenting, a one-off analysis.
Tagging something `na` is a decision; leaving it untagged is a gap, and a key that does
not parse into four segments is refused at issuance.

## Where versions are and are not allowed

Allowed, because the artefact *is* the version: golden sets (`gs-…-v3`), specifications
(`v1.4`, a field), decision records (numbered).

Not allowed, ever: agents, loops, skills, plugins, tools, repositories, identities. For
these, version is a field and the name is stable. A name that carries `-v2` guarantees
a `-v3` and orphans every trace keyed on the first.

## Renaming

A registered name does not change. To rename: create the new entry, set
`superseded-by` on the old one, migrate the cost tags at a lane boundary, and keep the
old entry visible until its traces age out. The same discipline as an architecture
decision record — append, never edit.
