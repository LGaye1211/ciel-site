---
name: shadow-review
description: Run and read a shadow comparison between a loop and the people doing the same work, quantify the four quadrants, name the disagreement patterns, and write the divergence report. Use this at step 6 of loop engineering, whenever someone needs to compare agent output against human judgment, asks how to prove a loop is ready, is deciding how much volume to trust an agent with, or reports that an agent seems to be working well. Impressions are not evidence - insist on the quadrants, because "it looks good" is exactly what precedes a tier granted on enthusiasm.
---

# Shadow run and divergence

Step 6 of nine. Weeks six to ten. The loop runs on live cases in parallel with the
team. It proposes; **nobody acts on its output.** What is measured is divergence — where
it disagrees with the human, and who was right.

## Before it starts

The instrumentation ships **before the loop does**. A shadow run without capture
produces impressions; a shadow run with capture produces the four quadrants. Teams that
build the loop first spend the shadow weeks retrofitting measurement and then argue
from anecdote at the gate.

Duration: four weeks minimum, and it must include a month-end and whatever the
seasonal peak is. Five weeks if a quarter-end falls nearby — take it.

## What to record, per case

What the loop proposed · what the human did · whether they agree · and where they
differ, **who was correct on review**. That last field is the one that gets skipped and
the one the whole report depends on.

## The four quadrants, plus one

| Quadrant | What it tells you |
|---|---|
| **Both correct** | The routine share. Expect this to be the large majority. It sets the ceiling on what tier 2 could cover. |
| **Loop right, human wrong** | Exists more often than people expect — usually prior-day history or a check the human skipped under time pressure. **The strongest single argument for the work**, and the one to lead with. |
| **Human right, loop wrong** | Categorise these. They are almost always three or four recurring patterns, not randomness. Each one must end the shadow period either explained and fixed, or bounded by a scope exclusion. |
| **Both wrong** | Rare, and always worth a close look: it usually means the rule itself is ambiguous. Refer it back as a rule question, not as a defect. |
| **Declined on confidence** | Not a failure. The intended behaviour, and the rate is a control you tune. |

## Exit criteria — agreed in advance, not at the end

Write these down before the run starts, because written before they are conclusions and
written after they are excuses:

- Agreement rate above a stated threshold on the routine share
- **No wrong action in the highest-severity category** — this one is absolute
- Every disagreement pattern either explained and fixed, or bounded by a scope exclusion

## Scope does not change mid-run

"While we're at it, let's also handle…" invalidates every case collected so far. New
scope is a new version, after graduation. Say this once at the start and it will not
come up again.

## Output — the divergence report

```
DIVERGENCE REPORT · <loop> · <dates>
SHADOW PERIOD      <n> weeks · month-end included: yes · quarter-end: yes/no
CASES DOUBLE-RUN   <n>

BOTH CORRECT             <%>   <which categories>
LOOP RIGHT, HUMAN WRONG  <%>   <why — this is your strongest evidence>
HUMAN RIGHT, LOOP WRONG  <%>   <named patterns, one line each>
BOTH WRONG               <%>   <rule implications>
DECLINED ON CONFIDENCE   <%>   <correctly? intended behaviour?>
                        (sums to 100)

PATTERNS
  <pattern 1>  → closed by <what was done, and by whom>
  <pattern 2>  → bounded by scope exclusion <which>, pending <what>
  <pattern 3>  → open  ← if any pattern is open, say so plainly

EXIT CRITERIA    each one, met or not met, with the number
RECOMMENDED      tier <n>, limited to <which categories>, covering ~<%> of worked volume
HELD BACK        which categories stay at the lower tier, and why
```

## Reading it honestly

Three things to check before you take it to the board:

1. **Is the recommendation one step?** Tier 0 to tier 2 is two steps and will be
   refused. Nothing skips a tier.
2. **Is it a tier increase *or* a scope widening?** Never both in one submission. Each
   is a separate decision with its own evidence.
3. **Would it have worked without the best engineer in the firm?** If the result depended
   on one person's continued attendance, it proves the people, not the model. Ask this
   at the outset and write the answer down.

## Then

`loop-graduate` — assemble the evidence pack and propose a tier.
