---
name: loop-graduate
description: Assemble the evidence pack for the graduation board and propose an autonomy tier - specification, signed baseline, divergence report, registry entry, runbook, rollback and kill-switch results. Use this at step 7 of loop engineering, whenever someone wants to move an agent from proposing to acting, asks for more autonomy, is preparing for a go-live decision or a gate review, or says a pilot has gone well and should be rolled out. Use it also to sanity-check a submission before it is made - a tier granted on enthusiasm is the failure this step exists to prevent.
---

# Graduating a loop, with an autonomy tier

Step 7 of nine. Weeks ten to eleven. Forty-five minutes at the fortnightly graduation
board — four people, **three possible outcomes: graduate, adopt elsewhere, or kill.**

## The five autonomy tiers

| Tier | What it means | Evidence required to reach it |
|---|---|---|
| **0** | Shadow. Proposes; nobody acts. | A specification and a golden set. Where every loop begins. |
| **1** | Proposes; a human accepts each case. | Four weeks of shadow with agreement above the agreed threshold. |
| **2** | Acts on the routine share below a confidence threshold; proposes the rest. | No wrong action in the high-severity category during shadow; every disagreement pattern explained or bounded. |
| **3** | Acts on most cases; a human reviews a sample and all exceptions. | Three months at tier 2 with intervention rate falling and no material incident. |
| **4** | Acts; a human reviews exceptions only. | Twelve months at tier 3, a stable golden-set pass rate, and an explicit business-owner decision. Rare, and **never for amendments**. |

Tiers are earned on evidence and withdrawn on evidence. **Nothing skips a tier, and
nothing reaches tier 3 in its first year.**

Tiers can be granted **per category**. This is usually the right answer: tier 2 on the
four routine categories, tier 1 on the five that need thought. Partial grants are a
sign of a well-read submission, not a weak one.

## The pack

Bring all six. A submission missing any of them is not heard.

1. **Specification**, versioned, with act classification reviewed by the Architecture Board
2. **Baseline sheet**, signed and dated *before* build began
3. **Divergence report** with the four quadrants quantified, not summarised
4. **Registry entry**, draft, with both owners named individuals
5. **Runbook**, written and exercised at least once
6. **Rollback and kill-switch test results** — tested in production, not only in staging

Plus, from the pod: the cost model built from tagged traffic, and evidence that cost
tagging works end to end.

## What the board will push on

**Is the proposal one step?** Tier 0 to 2 is two steps. Refused.

**Is it a tier increase or a scope widening?** Never both in the same submission.
Widening scope as a reward for a good result is the most common way a clean loop
becomes a messy one.

**What did not happen?** A good submission names it: no jump to tier 3, no extension to
the next loop on the strength of this one's result, no widening of scope. Saying this
out loud reads as discipline and shortens the meeting.

**What would have stopped this?** The stopping criteria, written before the work began,
each one reported against. That they did not fire is only meaningful because they were
written down in advance.

**Who accepts the residual risk?** The named business owner, in the room, in writing.

## Conditions are normal

Most grants carry them: a weekly sample review for the first quarter, an exclusion that
stays until a data fix is confirmed, a rate reported monthly. Propose the conditions
yourself rather than waiting to be given them.

## Output

```
GRADUATION SUBMISSION · <loop> · <date>

PROPOSING          tier <n>, limited to <categories>, ~<%> of worked volume
                   remaining categories stay at tier <n-1>
EVIDENCE
  specification    v<x> · act classification reviewed <date>
  baseline         signed <name> <date — before build>
  divergence       <weeks>, <cases>, quadrants: <..>
  registry entry   draft attached · business owner <name> · technical owner <name>
  runbook          written <date> · exercised <date>
  rollback/kill    tested in production <date>
STOPPING CRITERIA  <each, agreed before work began, reported against>
CONDITIONS PROPOSED
  <e.g. weekly 10% sample review for one quarter>
  <e.g. custodian X remains excluded until format change confirmed>
  <e.g. declined rate reported monthly>
NOT PROPOSED       <what was deliberately left out, and why>
RESIDUAL RISK      accepted by <name>, <role>, in writing
REVIEW             <date, normally three months>
```

## After the decision

Graduate → the registry entry goes live, `loop-run` starts, and the review date is
diarised. Kill → that is a healthy and expected outcome; the kill rate at the board
should be non-zero. Adopt elsewhere → someone else's service gets it, which is the
cheapest loop anyone ever builds.
