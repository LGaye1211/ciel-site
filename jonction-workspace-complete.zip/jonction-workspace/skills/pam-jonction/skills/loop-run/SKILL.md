---
name: loop-run
description: Produce and read the monthly page for a live loop - intervention rate, golden-set pass rate, cost per resolved case, new exception patterns, drift and cost alerts - and decide what to do about each. Use this at step 8 of loop engineering, whenever someone owns a running agent and needs to review it, asks how to monitor an agent in production, prepares for a quarterly platform review, or reports that a loop is running fine. Use it especially when the intervention rate is falling toward zero, which usually means supervision stopped rather than that the loop improved.
---

# Running a loop: the monthly page

Step 8 of nine. Ongoing, owned by the business owner. One page a month, five readings,
each with an action attached.

## The five readings

**1 · Intervention rate — how often a human overrode the loop.**
Rising is a warning: the world changed, or scope crept. **Falling toward zero is also a
warning**, and it is the one people misread as success. It usually means nobody is
checking. Cross-check it against whether the sample review actually happened.

**2 · Golden-set pass rate — re-run automatically, nightly.**
A drop means either the world changed or the loop drifted; both need investigation, and
the per-category breakdown points at which. A drop in a **single category** matters even
when the overall score holds — aggregate scores hide category collapse.

**3 · Cost per correctly resolved case — against the baseline you signed.**
Report steady-state and fully loaded side by side. Direction matters more than level. A
rising agent cost at flat volume means scope or retrieval has crept.

**4 · New exception patterns.**
This is how you find out that a counterparty changed a format or a market convention
moved — in week two rather than at quarter-end. One or two a month is healthy. Zero for
three months means the watcher is not working.

**5 · Drift and cost alerts raised by agent operations.**
You decide whether to pause. You do not need anyone's agreement to do it.

## Second-order effects are what the business actually feels

The headline saving is time per case. The value people notice is usually elsewhere: the
aged tail falling, quarter-end overtime disappearing, experienced people spending
mornings on judgment rather than retrieval.

**Lead the monthly page with the second-order effect and put the unit cost underneath
it.** It is more honest and it is more persuasive, because it is the thing the person
reading it has actually observed.

## Output

```
MONTHLY PAGE · <loop> · <month>

MEASURE                        VALUE          READING
Volume handled at tier <n>     <%>            <in line with graduation? / drifted?>
Intervention rate              <%>, <dir>     <healthy / investigate — zero is a warning>
Golden-set pass rate           <%>, <dir>     nightly; <n>-point drop pages the pod
Touch time per worked case     <min> (was <>) <where the saving actually sits>
Cost per correctly resolved    CHF <> (was <>) steady state · fully loaded CHF <>
90th percentile cycle time     <d> (was <>)   the tail — what the business feels
Aged items                     <n> (was <>)   second-order effect
New exception patterns         <n>            <what they were>
Alerts                         <n>            <drift / cost / tool — each closed out?>

DECISIONS THIS MONTH
  <threshold moved from x to y, against measured accuracy — record every move>
  <scope exclusion lifted / added>
  <pause taken, and why>
SCOPE            still matches what was graduated: yes/no
NEXT REVIEW      <date>
```

## The quarterly and annual obligations

**Quarterly** — refresh a portion of the golden set with recent cases, and bring the
three cost numbers to the platform review unprompted, with the baseline attached.
Bringing them before being asked is the difference between a service that is trusted
with more and one that is asked to justify what it has.

**Annually** — re-attest the registry entry: still needed, still correctly scoped, still
yours. An unattested entry is disabled at the sweep, not inherited.

## Your standing rights

You may pause the loop without asking anyone. Pausing is cheap and reversible; a
running loop makes more of whatever it is doing wrong. You may also decide, at step 9,
to expand, hold or retire — and **hold is the outcome for most loops, and is a success.**
Retiring is normal and should carry no stigma; an unretired, unused loop is an orphan
and will be disabled at the annual sweep.
