---
name: loop-map
description: Map a repeating business process as it is actually performed - trigger, steps, undocumented steps, decision points, end states with proportions, and exception patterns. Use this at step 1 of loop engineering, whenever someone needs to document how work really gets done before automating it, wants to write a process map or as-is analysis, or has been asked what their team actually does all day. Insist on this before any specification is written; a specification built on the procedure document rather than the observed work is the most expensive error in the method.
---

# Mapping a loop as it actually is

Step 1 of nine. One to two weeks, owned by the business manager.

## The rule that makes this worth doing

**Observe, do not interview.** People describe the rule they believe they follow;
watching reveals the rule they actually follow. The difference between the two is
where all the value is — it is the local spreadsheet of custodian quirks, the colleague
who covers that market, the personal threshold below which something is left to age.

If you are running this as a conversation rather than sitting with the work, say so
explicitly in the output, because a map built from description alone is a draft, not a
map, and the pod will find the gap in week eight.

## Capture, in this order

**Trigger.** What starts a case. A file arrival, a threshold breach, a clock, a request.
Be precise: "a break appears on the exception queue after the overnight match run" is a
trigger; "when there's a mismatch" is not.

**Steps.** Each action in sequence — including the ones nobody documents. Actively hunt
for these three, because they are almost always present and almost never written down:
the second screen someone checks, the colleague they ask, the mental rule about which
source wins.

**Decision points.** Where a judgment is made, what evidence it uses, what the options
are. Most loops have one or two real decision points and eight steps of evidence
gathering. Separating the two is the single most useful thing this map produces —
evidence gathering is usually the cheapest, lowest-risk loop to build first.

**End states.** Every way a case can finish, *with rough proportions*, including
"parked" and "escalated". Proportions matter more than completeness: they tell you
where the volume is and therefore where the value is.

**Exception patterns.** The cases that break the pattern, and roughly how often. Write
these down even when they feel like noise. They almost always turn out to be three or
four recurring patterns rather than randomness, and naming them early is what lets the
loop exclude them cleanly instead of failing on them quietly.

## The honest test, before you go further

Ask the two people who do this work to write down, separately, how they decide.

If the descriptions differ materially, there is no loop yet — there is a craft two
people practise differently. That is a finding worth having, it is fixable, and it
comes before any agent. Settle it as a business decision and the existing manual
process gets better whether or not a loop is ever built.

## Output

A one-page map. Two pages maximum — if it runs longer, it is several loops and should
be split. Use this shape:

```
SERVICE        <name> · product home <product>
TRIGGER        <precisely what starts one instance>
STEPS          1..n, numbered, in observed order
UNDOCUMENTED   the second screen, the colleague, the local rule
DECISION POINTS  <which step numbers, what evidence, what options>
END STATES     each, with approximate share, summing to 100%
EXCEPTIONS     named patterns with rough frequency
WHERE IT SITS  which parts are engagement / action / record
SPLIT?         if this is more than one loop, name the parts and their risk profiles
```

## Splitting is usually the right answer

A service is rarely one loop. Separating it is often the most consequential decision in
the whole exercise, because each part has a different risk profile and a different
readiness. A typical split: one loop that only gathers evidence (read-only, lowest
risk, largest immediate time saving), one that classifies or decides (proposes only),
and one that acts outward (writes forward, higher blast radius, goes last).

Build the read-only one and the proposing one first. The one that acts outward waits
until the proposing one has earned a tier.

## Then

`loop-baseline` — and start it now, in parallel. The baseline measures a period that
has to include a month-end, and it cannot be reconstructed afterwards.
