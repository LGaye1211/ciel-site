---
name: runbook-write
description: Write the runbook for a live loop - alert triggers, first action, who to notify, how to scope what was touched, diagnosis order, resume procedure and kill switch. Use this before any loop goes live, after every incident without exception, when someone asks how to operate an agent in production, or when on-call is being extended to agentic behaviour. Runbooks for probabilistic systems differ from ordinary ones in one crucial respect - the first action is to pause, not to investigate - so use this rather than adapting a conventional service runbook.
---

# The runbook for a probabilistic system

Written before go-live, beside the code, **exercised after every incident without
exception**. The test of a runbook is whether someone paged at three in the morning who
did not build the loop can act on it.

## The rule that makes this different

**Contain first. Pause the loop before investigating.**

Pausing is cheap and reversible; a running loop makes more of whatever it is doing
wrong. This inverts the instinct of most engineers, who investigate first because that
is what a deterministic outage rewards. State it as the first action, explicitly, in
capital letters if necessary.

Say what the pause costs, too, in business terms — *"cases route to humans; the queue
absorbs roughly forty extra cases a day"* — so the person on call knows the pause is
survivable and does not hesitate.

## The four alert classes

| Class | Response |
|---|---|
| **Wrong action in a high-severity category** | Page immediately. Pause the loop. Inform the business owner the same day. |
| **Drift** — evaluation pass rate or output distribution moving | Investigate within the day. **Auto-pause on the second occurrence in a week**, per the specification. |
| **Cost anomaly** — ceiling breached, or cost per case rising at flat volume | Usually scope creep or retrieval bloat; occasionally an upstream change. |
| **Tool or source failure** — a connector down, a schema changed | The loop should **degrade to proposing rather than guessing**. Check that it did. |

## Three-line support

Automation handles the recurring and the known · the rotation handles the rest · **the
building engineer is the last resort, not the first.** A pod of five cannot sustain a
rota that pages the same person every time, and a runbook that names an individual
rather than a rotation has quietly recreated that dependency.

## Diagnosis order — most common cause first

This is the section that saves the most time and is most often written in the wrong
order. Put the boring causes at the top:

1. Upstream schema or format change — check the contracts dashboard
2. A new exception pattern — check the watcher output
3. Model pin changed without evaluation — *should be impossible; if it happened, that is
   an incident in itself*
4. Context or retrieval regression from a recent merge

## Output

```
RUNBOOK · <loop> · owner <name> · last exercised <date, by whom>

WHAT IT DOES        Two lines, readable by someone paged at 03:00 who did not build it.

ALERT TRIGGERS      <condition> → severity <n>
                    ...

1 PAUSE             Do not investigate first. <what happens to the work meanwhile,
                    in business terms>
2 NOTIFY            <business owner, by name and role> — same day
3 SCOPE             Query the registry and traces for every case touched in the
                    window. Flag any case acted on at tier 2 for human re-review.
4 DIAGNOSE          in order, most common first:
                    a <...>   b <...>   c <...>   d <...>
5 FIX               Normal delivery standard. No hotfix without evaluation evidence.
6 RESUME            Progressive: <named slice> → <n>% of volume → full.
                    Divergence capture stays live throughout.
7 LEARN             Failing cases to Assurance for golden-set inclusion.
                    Runbook updated before the incident is closed. No exceptions.

KILL SWITCH         <how, by whom> · last tested in production <date>
ROLLBACK            <path> · last rehearsed <date>
```

## Two habits that keep it honest

**Exercise it.** A runbook nobody has run is a document, not a control. Rehearse the
kill switch and the rollback in production at least quarterly and record the date — in
the runbook and in the registry entry. An untested kill switch is a belief.

**Update it before closing.** The incident is not closed until the runbook reflects what
was learned. This is the discipline that makes the second occurrence of anything
cheaper than the first, and it is the first thing dropped under pressure.
