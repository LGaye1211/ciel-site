---
name: loop-triage
description: Screen a candidate process before anyone builds anything - decide whether it is a loop, whether it is the right first loop, and where to route it. Use this whenever someone proposes automating a process, asks "could an agent do this?", wants to put AI on a workflow, brings a candidate to intake triage, or describes a repetitive task they would like handled automatically. Use it even when the request sounds obviously sensible - two of the five questions stop projects that would otherwise consume a quarter and produce nothing.
---

# Screening a loop candidate

Most failed agent projects were doomed at the moment someone picked the process, not
at the moment someone built it. This screen costs twenty minutes and is the highest-
return twenty minutes in the whole method.

## What you are deciding

Three outcomes, and only one of them is "build it":

- **Route to a builder.** Roughly a third of requests are solvable in an afternoon by
  someone with the right connector. No project, no specification.
- **Specify it as a loop.** It passes all five questions. Go to `loop-map`.
- **Not this one, not yet.** Name what is missing and what would change the answer.
  This is a real outcome, not a failure, and saying it now is much cheaper than saying
  it in month four.

## The agent-first rule comes first

Before any of the five questions: has someone actually attempted this with an agent
and documented why it failed? If not, that attempt *is* the next step. No project opens
without it. This is not a hurdle — it is the fastest route, and it routinely returns
"already solved" on requests that were about to become a quarter of delivery work.

## The five questions

Ask them in this order and stop at the first hard no.

**1 · Is it a loop?**
It repeats, the trigger is identifiable, and the end states are countable. Push for
numbers: how many times a week, what starts it, how many ways can a case finish.
*If each case is genuinely unique, stop.* That is a craft, not a loop, and agents will
not help it this year.

**2 · Is the evidence in a system?**
The information needed can be queried by somebody, rather than living in an inbox, an
attachment or a colleague's memory.
*If the evidence arrives by email, the first project is getting it into a system.*
Route to Data & Knowledge Engineering, not to an agent.

**3 · Can they produce two hundred past cases with the right answer?**
This is the golden set and it is the gating item. Ask who would do it and when.
*If producing it is hard, that difficulty is the finding:* the work is not currently
measurable, and nobody will be able to say whether the loop helped.

**4 · What does a wrong answer cost?**
Be specific. Caught downstream by a control, or reaches a client?
*If it reaches a client or a regulator with no intervening check, this is not a first
candidate.* Look for the loop behind it instead — the one whose output the control
checks.

**5 · Who accepts the residual risk?**
A named individual in the business who will sign the registry entry as business owner
and attest to it annually. Not a committee, not a function, not "operations".
*If nobody will put their name to it, the work is not ready.* That is an honest
answer rather than an obstacle, and it is better heard now.

## What makes a good first candidate

Fifty or more instances a week · evidence already in systems · the rule is genuinely a
rule rather than a matter of taste · a wrong answer is caught by something downstream ·
twelve months of past cases are retrievable.

## The most common false start, and say it out loud

People pick the process that annoys them most rather than the one that is most
tractable. Annoyance correlates almost perfectly with the involvement of other people,
external parties and unstructured evidence — which is exactly what makes a loop hard.

Say this plainly: **pick the boring high-volume one first; earn the right to the
annoying one.** It lands better than it sounds, because everyone recognises it.

## Output

Produce this, short:

```
CANDIDATE   <service · process, one line>
VOLUME      <instances per week, peak>
VERDICT     build as a loop | route to a builder | not yet
FIVE QUESTIONS
  loop?        yes/no + evidence
  evidence?    yes/no + where it lives
  200 cases?   yes/no + who would produce them, when
  wrong answer? caught downstream | reaches a client
  named owner? <name> | none
IF NOT YET    what is missing, and what would change the answer
NEXT STEP     <the one thing that happens next, with a person against it>
```

## Then

Passing all five goes to `loop-map` (step 1) and `loop-baseline` (step 2). Do not skip
to specification — a specification written from what people *say* they do rather than
what they *do* is the second most expensive mistake in the method.
