---
name: refusal-check
description: Test whether a request should be declined, and word the refusal so it lands - no specification, no baseline or golden set, or below break-even volume. Use this when a delivery team is asked to build something that is not ready, when someone needs to say no to a stakeholder and wants the argument to be defensible, when volume looks too low to justify a loop, or when a request arrives as a wish rather than a rule. A team that cannot decline work becomes a queue, so use this early rather than after three weeks of trying to make it work.
---

# Refusing well

A delivery team that cannot decline work becomes a queue. Three refusals are
legitimate. Made early and in plain terms, they build credibility; made late, they read
as excuses.

**Refusals go through the product owner, not around them.** A tech lead who negotiates
scope directly with the business has broken the dual key, and will be asked to do it
again properly.

## The three legitimate refusals

### 1 · No specification

> "We will build this once the rule is settled. Here is exactly what is ambiguous:
> [list the fields]. Each one is a business decision, and we cannot make it for you
> without guessing."

This is the analyst's job and it should not reach the tech lead. Filling a gap with an
assumption is how a loop ends up correctly implementing something nobody wanted.

**Attach the list.** A refusal with three named ambiguities is a work item for the
business. A refusal without them is obstruction.

### 2 · No baseline, or no golden set

> "We can build it, but nobody will be able to say whether it worked — including you, in
> front of your own management."

Usually sufficient, because it is framed as protecting the requester rather than the
team. The baseline cannot be reconstructed afterwards, so the moment to say this is
before the build, not during it.

### 3 · Below break-even volume

> "At this volume the loop costs more than the people. Here is the arithmetic."

**The most valuable refusal anyone makes**, and the one that builds the most credibility
— because it demonstrates that the team is optimising the firm's money rather than
maximising its own backlog.

Show the working: fixed annual cost (amortised build + platform share + maintenance)
divided by the saving per case gives the break-even volume. Compare it against actual
volume. Use `loop-cost` to get the numbers right before you quote them; a refusal with
arithmetic that does not survive scrutiny is worse than no refusal.

## What is *not* a legitimate refusal

- "We're busy." That is a priority conversation for the product owner, not a refusal.
- "The technology isn't ready." Say what specifically is missing and what would change
  it, or it reads as reluctance.
- "It's too risky." Name the act, the blast radius and the control that is missing. Risk
  without a named act is an opinion.
- Declining a **review-bot finding, a CI failure, or a control requirement** on grounds
  of workload. Those are not requests.

## Output

```
REQUEST         <what was asked, one line, in the requester's words>
VERDICT         decline | decline for now | accept with conditions
GROUND          no specification | no baseline or golden set | below break-even
THE ARGUMENT    <two or three sentences, addressed to the requester's interest>
EVIDENCE        <the named ambiguities / the missing artefact / the arithmetic>
WHAT WOULD CHANGE IT
                <the specific thing that turns this into a yes>
ROUTED THROUGH  product owner <name>
RECORDED        <where — refusals are part of the method and worth keeping>
```

## Record them

Refusals are part of the record, not an absence of work. A short log of what was
declined and why — with the arithmetic — is one of the more persuasive things a team can
bring to a platform review, because it shows the discipline that makes the accepted
work credible.
