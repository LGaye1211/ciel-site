---
name: loop-baseline
description: Measure and sign the baseline for a process before any build work begins - volume, cycle time, touch time, cost per case, current error rate and difficulty split. Use this at step 2 of loop engineering, whenever someone needs a before picture, wants to justify or later prove the value of an automation, is preparing a business case, or is about to start building without numbers. This is the one artefact that cannot be reconstructed afterwards, so raise it even when nobody asked - six months later it is the difference between evidence and anecdote.
---

# Measuring the baseline

Step 2 of nine. Two to three weeks, owned by the business manager, signed and dated
before a single line of anything is built.

## Why this is the gating artefact

Nothing that comes later is meaningful without it, and it cannot be reconstructed
afterwards. The most common way an agent programme fails is not that the loop did not
work — it is that six months in, nobody can say whether it helped. That failure is
unrecoverable, because the past cannot be measured retrospectively.

The correct response to "let's start and measure as we go" is that there is nothing to
measure against. Say it once, plainly, and refuse to start.

## Measure over a representative period

Ideally a full month including a month-end. If the service has a quarter-end peak, say
so and note that the shadow run will need to cover one.

## The eight measures

| Measure | How, and what people get wrong |
|---|---|
| **Volume** | Cases per day and per week, with the peak day named. Peaks matter more than means — they are when the process actually hurts. |
| **Cases needing human work** | Distinct from volume. Many processes have large transient volume that clears itself. This subset is the denominator of everything that follows. |
| **Cycle time** | Median *and* ninetieth percentile, trigger to closure. The tail matters more than the average; it is what the business actually feels. |
| **Touch time** | Actual minutes of human attention per case — not cycle time. **Sample it; do not estimate it.** Estimates of touch time are wrong by a factor of two in both directions, and the whole cost model hangs off this number. |
| **Cost per case** | Touch time times the fully loaded hourly rate, plus any external cost. Get the standard rate from Finance rather than inventing one. |
| **Current error rate** | How often the process gets it wrong today, and how you find out. Most teams have never measured this and are surprised. It is also what makes the eventual comparison honest, because the old process has an error rate too. |
| **Difficulty split** | Routine / needs thought / genuinely hard, as shares. Rarely what people expect, and it determines which portion of volume a loop could ever take. |
| **Aged items** | Whatever the service's version of a long tail is — items over thirty days, standing. Often the real pain point, and usually not where the volume is. |

## The trap

Measuring only the happy path. The value of a loop is usually in compressing the tail
rather than the median, so the ninetieth percentile and the exception rate are the
numbers you will need to defend later. A loop that halves median time and leaves the
tail untouched has produced much less than it appears to have.

## Output

A baseline sheet, dated, **signed by the business manager**. It is quoted in every
subsequent review and never re-derived.

```
BASELINE SHEET
SERVICE            <name>
PERIOD MEASURED    <dates> · includes month-end: yes/no · quarter-end: yes/no
VOLUME             <mean per day> · <peak day and value>
NEEDING HUMAN WORK <per day>   ← the denominator for everything
CYCLE TIME         median <x> · 90th percentile <y>
TOUCH TIME         <minutes per worked case> · sampled over <period>, not estimated
FULLY LOADED RATE  <CHF per hour> · source: Finance standard rate
COST PER CASE      <CHF> = touch time x rate
CURRENT ERROR RATE <%> · detected by <how>
DIFFICULTY SPLIT   <routine / thought / hard>
AGED ITEMS         <count over 30 days>
SIGNED             <name, role>            DATE <before build begins>
```

## How this gets used later

- `loop-cost` compares everything against `COST PER CASE` and computes break-even
  volume from it. Below break-even, a loop costs more than the people — and that
  arithmetic is the most valuable refusal anyone makes.
- `loop-graduate` will not accept a submission without a baseline signed *before* build
  started. A baseline dated after the build is not evidence.
- `loop-run` reports cost per resolved case against this sheet every month.

## If the numbers are hard to get

That is itself the finding, and it is worth reporting as one: the work is not currently
measurable. Instrumenting the queue — timestamps, touch-time sampling — is usually a
week of a pod engineer's time and is worth doing before anything else. The pod should
be asked to do this in week two, not week eight.
