---
name: registry-draft
description: Draft or review the agent registry entry - identity, owners, risk class, books touched with the act against each, entitlements, tool allow-list, autonomy tier, blast radius, cost ceiling, evaluation reference, kill switch and model pin. Use this whenever an agent is being registered, before any code is written for a new loop, when an owner leaves and an entry must be reassigned, at annual attestation, or when someone asks what is in the firm's AI inventory. The registry entry is not documentation - it is the control, and it is what the board and an auditor see.
---

# The registry entry

An agent is an actor, not a library. It has an identity, a mandate, a limit and an
accountable human. **The registry is the AI inventory reported to the board**, and the
second commitment — zero unknown agents, verified quarterly — is measured against it.

Draft the entry **before any code**, deliberately. An entry written afterwards
documents what was built; an entry written first constrains it.

## Tool or actor? The test that decides whether to register

> Does it act beyond the developer's own workstation, under its own identity?

An assistant suggesting code in an editor is a **tool**. The same model opening a pull
request against a repository that deploys, calling an API, or writing to a queue is an
**actor**, and is registered.

Get this wrong in either direction and it costs you: register tools and the inventory is
unusable within a quarter, which is worse than useless because people stop reading it.
Fail to register actors and the firm is in the unknown-agent population the second
commitment forbids.

## The fields

| Field | What is supplied, and the trap |
|---|---|
| **Name** | Per the naming standard: `<domain>-<verb>-<object>`. Run `name-check`. Immutable after registration — traces and cost tags key on it. |
| **Identity** | A dedicated non-human identity with short-lived credentials. **Never a shared technical account, never a borrowed human credential.** The fastest way to build a loop is one account every agent borrows; it destroys attribution, breaks entitlement propagation, and is the first thing an auditor finds. |
| **Technical owner** | A named person, normally the tech lead. When they leave, the entry is reassigned the same week or the agent is disabled. |
| **Business owner** | A named person **outside** the delivery team who accepts residual risk and attests annually. Not a committee. |
| **Risk class** | Derived from the act classification and whether output reaches a client or a regulator. |
| **Books touched** | Each book, with the act: read, propose, write forward. **Amend and rules must be absent.** If either appears, the loop is mis-specified — go back to `loop-classify`. |
| **Entitlements** | Propagated from the requesting human. Where the loop runs unattended, a scoped identity with the narrowest possible grant, reviewed quarterly. Scoping the *prompt* is not a control; enforcement is at the data layer. |
| **Tool allow-list** | Every tool and MCP server it may call. Anything absent is unavailable at the gateway, not merely discouraged. |
| **Autonomy tier** | Per category where categories differ, recorded with the evidence that earned it. |
| **Blast radius** | Worst case for one instance, in business units, **with the compensating control named**. |
| **Cost ceiling** | Per instance and per day, enforced at the gateway. |
| **Evaluation reference** | Golden-set identifier, threshold, drift tolerance. |
| **Kill switch** | How it is stopped, by whom, and **the last date the stop was tested in production**. An untested kill switch is a belief, not a control. |
| **Model pin** | Model and version, with the date of the last evaluated upgrade. Upgrades are a change with evaluation evidence, never automatic drift. |

## Three rules a team enforces on itself

**No shared accounts.** Per-agent identity from the first agent. Retrofitting attribution
is brutal.

**Entitlements at the data layer.** The loop must be *unable* to read what its caller
could not read, enforced where the data lives.

**No orphans.** When an owner leaves, the entry is reassigned the same week. The annual
sweep catches what was missed; it should never find anything.

## Output

```
REGISTRY ENTRY · <name>

IDENTITY        <non-human identity> · short-lived credentials · shared account: no
TECHNICAL OWNER <named individual> · <role>
BUSINESS OWNER  <named individual> · <role> · annual attestation <date>
RISK CLASS      <internal | client-facing | regulator-facing> ·
                <acts> · financial movement: yes/no
BOOKS TOUCHED   <book> (<act>) · <book> (<act>) ...
                amend: absent · rules: absent
ENTITLEMENTS    propagated from the requesting human · scoped to <...>
TOOL ALLOW-LIST <tool> · <tool> ...   any amend/write_rule tool requires ADR <ref>
AUTONOMY TIER   <n> on <categories>, <n> on <categories> — recorded per category
                evidence: <divergence report ref>
BLAST RADIUS    <worst case, in business units>
                compensating control: <what bounds it, reviewed by whom, how often>
COST CEILING    CHF <> per case · CHF <> per day · enforced at the gateway
EVALUATION      <golden set id> · threshold <%> · drift tolerance <n> points
KILL SWITCH     <how, by whom> · last tested in production <date>
MODEL PIN       <model> <version> · last evaluated upgrade <date>
GATEWAY KEYS    <team>.<lane>.<usecase>.<tier> ...
STATUS          draft | live | paused | retired · superseded-by <if renamed>
```

## Reviewing someone else's entry

Five things that are wrong most often: a shared account hiding behind a plausible name;
`amend` present in books touched; a blast radius written technically rather than in
business units; a kill switch with no tested date; and a business owner that is a
function rather than a person. Check those five first.
