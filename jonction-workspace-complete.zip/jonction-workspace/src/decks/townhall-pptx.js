const pptxgen = require("pptxgenjs");
const p = new pptxgen();
p.layout = "LAYOUT_WIDE"; // 13.3 x 7.5

const INK = "1C1C1A", PAPER = "F7F5F0", PAPER2 = "EFECE4";
const MUTED = "8B8983", MID = "4A4945", RULE = "D9D6CD", ACCENT = "7A5C2E", WHITE = "FFFFFF";
const SERIF = "Cambria", SANS = "Calibri";

const M = 0.85;              // left margin
const W = 13.33 - M * 2;     // content width

function notes(s, t) { s.addNotes(t); }

// ---------- helpers ----------
function darkSlide() {
  const s = p.addSlide();
  s.background = { color: INK };
  return s;
}
function lightSlide() {
  const s = p.addSlide();
  s.background = { color: WHITE };
  return s;
}
function title(s, txt, opts = {}) {
  s.addText(txt, {
    x: M, y: opts.y || 0.62, w: opts.w || W, h: 0.9,
    fontSize: opts.size || 34, fontFace: SERIF, color: opts.color || INK,
    bold: false, align: "left", isTextBox: true, margin: 0
  });
}
function kicker(s, txt, color) {
  s.addText(txt.toUpperCase(), {
    x: M, y: 0.35, w: W, h: 0.25, fontSize: 10, fontFace: SANS,
    color: color || ACCENT, charSpacing: 2.2, isTextBox: true, margin: 0
  });
}
function footnote(s, txt, color) {
  s.addText(txt, {
    x: M, y: 6.85, w: W, h: 0.3, fontSize: 10, fontFace: SANS,
    color: color || MUTED, isTextBox: true, margin: 0
  });
}

// =========================================================
// 1 — TITLE
// =========================================================
{
  const s = darkSlide();
  s.addText("PICTET ASSET MANAGEMENT  ·  TECHNOLOGY & OPERATIONS", {
    x: M, y: 0.75, w: W, h: 0.3, fontSize: 11, fontFace: SANS,
    color: MUTED, charSpacing: 2.5, isTextBox: true, margin: 0
  });
  s.addText("Jonction", {
    x: M, y: 2.15, w: 8, h: 1.6, fontSize: 72, fontFace: SERIF,
    color: PAPER, isTextBox: true, margin: 0
  });
  s.addText("How we will build, and who we will be, as an agentic asset manager.", {
    x: M, y: 3.9, w: 8.6, h: 1.0, fontSize: 21, fontFace: SERIF,
    color: "CFCCC4", isTextBox: true, margin: 0
  });
  s.addShape(p.ShapeType.line, { x: M, y: 6.15, w: 2.2, h: 0, line: { color: ACCENT, width: 1.5 } });
  s.addText("Town hall  ·  Geneva  ·  September 2026", {
    x: M, y: 6.35, w: 7, h: 0.3, fontSize: 12, fontFace: SANS, color: MUTED, isTextBox: true, margin: 0
  });
  notes(s, "Open by naming the room's actual question: 'Am I still needed?' Answer it in the first two minutes, not the last. Jonction — where the Rhone and the Arve meet. Two currents, one river.");
}

// =========================================================
// 2 — THE ONE SENTENCE
// =========================================================
{
  const s = lightSlide();
  kicker(s, "Start here");
  s.addText("Headcount neither grows\nnor shrinks because of AI.", {
    x: M, y: 1.9, w: 11.2, h: 2.2, fontSize: 44, fontFace: SERIF, color: INK,
    lineSpacing: 52, isTextBox: true, margin: 0
  });
  s.addText("What changes is what we do.", {
    x: M, y: 4.2, w: 11, h: 0.6, fontSize: 26, fontFace: SERIF, color: ACCENT, italic: true, isTextBox: true, margin: 0
  });
  s.addShape(p.ShapeType.line, { x: M, y: 5.25, w: W, h: 0, line: { color: RULE, width: 1 } });
  s.addText("This is a commitment, in writing, not a reassurance. Everything else in this presentation depends on you believing it — so judge me on it.",
    { x: M, y: 5.5, w: 10.5, h: 0.8, fontSize: 15, fontFace: SANS, color: MID, isTextBox: true, margin: 0 });
  notes(s, "Say it slowly. Pause. Do not soften it with qualifiers. If someone asks 'what about natural attrition' — answer honestly: roles change, the number doesn't move because of AI.");
}

// =========================================================
// 3 — WHY NOW (three stats)
// =========================================================
{
  const s = lightSlide();
  kicker(s, "Why now");
  title(s, "The market has already split in two.");
  const cards = [
    { n: "25%", t: "of technology leaders report\nmeaningful acceleration from AI", c: INK },
    { n: "30%", t: "report their teams got\nslower, not faster", c: ACCENT },
    { n: "2×", t: "the success rate when roles and\nworkflows are redesigned, not just tooled", c: INK },
  ];
  cards.forEach((c, i) => {
    const x = M + i * ((W - 0.6) / 3 + 0.3);
    const w = (W - 0.6) / 3;
    s.addShape(p.ShapeType.rect, { x, y: 2.1, w, h: 2.9, fill: { color: PAPER } });
    s.addText(c.n, { x: x + 0.35, y: 2.45, w: w - 0.7, h: 1.0, fontSize: 58, fontFace: SERIF, color: c.c, isTextBox: true, margin: 0 });
    s.addText(c.t, { x: x + 0.35, y: 3.6, w: w - 0.7, h: 1.2, fontSize: 14, fontFace: SANS, color: MID, isTextBox: true, margin: 0 });
  });
  s.addText("The difference is never the tools. It is whether the way of working changed.", {
    x: M, y: 5.45, w: 11.5, h: 0.6, fontSize: 19, fontFace: SERIF, color: INK, isTextBox: true, margin: 0
  });
  footnote(s, "McKinsey, survey of 334 product and engineering leaders, August 2026");
  notes(s, "Thirty per cent got SLOWER. That is the number to dwell on — it means this is not automatic, and it means our care about how we do it is not bureaucracy, it is the difference between the two cohorts.");
}

// =========================================================
// 4 — THE THREE LAYERS
// =========================================================
{
  const s = lightSlide();
  kicker(s, "The architecture");
  title(s, "Our systems are sorting into three kinds.");
  const rows = [
    { h: "Systems of engagement", d: "Cowork, Claude Code, our portals — where people say what they want", y: 2.05 },
    { h: "Systems of action", d: "Order routing, Themis, reconciliation, content assembly — where work executes", y: 3.25 },
    { h: "Systems of record", d: "IBOR, ABOR, client, counterparty, mandates — what is true", y: 4.45 },
  ];
  rows.forEach(r => {
    s.addShape(p.ShapeType.rect, { x: M, y: r.y, w: 8.3, h: 1.0, fill: { color: PAPER } });
    s.addText(r.h, { x: M + 0.35, y: r.y + 0.14, w: 7.6, h: 0.35, fontSize: 18, fontFace: SERIF, color: INK, isTextBox: true, margin: 0 });
    s.addText(r.d, { x: M + 0.35, y: r.y + 0.52, w: 7.6, h: 0.35, fontSize: 13, fontFace: SANS, color: MID, isTextBox: true, margin: 0 });
  });
  s.addShape(p.ShapeType.rect, { x: M + 8.75, y: 2.05, w: 2.75, h: 3.4, fill: { color: INK } });
  s.addText("Control plane", { x: M + 9.05, y: 2.35, w: 2.2, h: 0.4, fontSize: 17, fontFace: SERIF, color: PAPER, isTextBox: true, margin: 0 });
  s.addText("Registry\nGateway\nIdentity\nEvaluations\nCost\nProvenance", {
    x: M + 9.05, y: 3.0, w: 2.2, h: 2.2, fontSize: 13, fontFace: SANS, color: "CFCCC4", lineSpacing: 20, isTextBox: true, margin: 0
  });
  s.addText("Every actor writes only through the record's own contract, only forward, and never to the rules that constrain it.", {
    x: M, y: 5.8, w: 11.5, h: 0.7, fontSize: 17, fontFace: SERIF, color: ACCENT, italic: true, isTextBox: true, margin: 0
  });
  notes(s, "This is the intellectual core. Say the rule out loud twice. Give the Themis example: it writes constituents, it never rewrites the inclusion criteria. Same for the order chain and the mandate.");
}

// =========================================================
// 5 — WHAT WE PROTECT
// =========================================================
{
  const s = lightSlide();
  kicker(s, "What makes us an asset manager");
  title(s, "Nine books. Agents read and propose.\nHumans authorise.", { size: 32 });
  const books = ["IBOR", "ABOR", "Counterparty", "Client", "Mandates", "Product", "Performance", "Approved content", "Distribution data"];
  books.forEach((b, i) => {
    const col = i % 3, row = Math.floor(i / 3);
    const w = (W - 0.7) / 3;
    const x = M + col * (w + 0.35), y = 2.75 + row * 0.95;
    s.addShape(p.ShapeType.rect, { x, y, w, h: 0.75, fill: { color: PAPER2 } });
    s.addText(b, { x: x + 0.3, y: y + 0.18, w: w - 0.5, h: 0.4, fontSize: 15, fontFace: SERIF, color: INK, isTextBox: true, margin: 0 });
  });
  s.addText("An agent may place an order within a mandate. It may not correct a position.", {
    x: M, y: 5.85, w: 11.5, h: 0.6, fontSize: 18, fontFace: SERIF, color: ACCENT, italic: true, isTextBox: true, margin: 0
  });
  notes(s, "Nobody outside our walls will build this for us. This is the part of the job that is specific to being an asset manager, and it is why our work is not commoditised by a model release.");
}

// =========================================================
// 6 — THE ORGANISATION
// =========================================================
{
  const s = lightSlide();
  kicker(s, "The organisation");
  title(s, "Four platforms. Four chapters. One office.");
  const plats = [
    { n: "Investment", d: "Front office" },
    { n: "Client", d: "Distribution" },
    { n: "Corporate", d: "Ops, finance, risk" },
    { n: "Intelligence", d: "Platform + control plane" },
  ];
  plats.forEach((c, i) => {
    const w = (W - 0.9) / 4;
    const x = M + i * (w + 0.3);
    const dark = i === 3;
    s.addShape(p.ShapeType.rect, { x, y: 2.05, w, h: 1.5, fill: { color: dark ? INK : PAPER } });
    s.addText(c.n, { x: x + 0.25, y: 2.32, w: w - 0.45, h: 0.45, fontSize: 18, fontFace: SERIF, color: dark ? PAPER : INK, isTextBox: true, margin: 0 });
    s.addText(c.d, { x: x + 0.25, y: 2.82, w: w - 0.45, h: 0.5, fontSize: 12, fontFace: SANS, color: dark ? "CFCCC4" : MUTED, isTextBox: true, margin: 0 });
  });
  s.addShape(p.ShapeType.rect, { x: M, y: 3.85, w: W, h: 1.15, fill: { color: PAPER2 } });
  s.addText("Four chapters — your craft, your standards, your career", {
    x: M + 0.35, y: 4.02, w: 10, h: 0.4, fontSize: 16, fontFace: SERIF, color: INK, isTextBox: true, margin: 0
  });
  s.addText("Software Engineering    ·    Business Analysis & Design    ·    Platform & Reliability Engineering    ·    Data & Knowledge Engineering", {
    x: M + 0.35, y: 4.48, w: 11.3, h: 0.4, fontSize: 13, fontFace: SANS, color: MID, isTextBox: true, margin: 0
  });
  s.addText("Platforms decide what we build. Chapters decide how well we build it. Nobody belongs to a project — everybody belongs to a craft.", {
    x: M, y: 5.4, w: 11.5, h: 0.8, fontSize: 17, fontFace: SERIF, color: INK, isTextBox: true, margin: 0
  });
  notes(s, "Name the renames plainly: DevOps becomes Platform & Reliability; Data Engineering becomes Data & Knowledge; BA becomes Business Analysis & Design. Explain that the fourth platform becomes Intelligence — this is where the control plane is built.");
}

// =========================================================
// 7 — WHAT CHANGES FOR ROLES
// =========================================================
{
  const s = lightSlide();
  kicker(s, "What changes for you");
  title(s, "From producing artefacts to owning outcomes.");
  const rows = [
    { a: "Engineers", b: "Write most first drafts by hand", c: "Specify, review, own architecture and limits — and run what you build" },
    { a: "Analysts", b: "Write specification documents", c: "Own correctness: evaluations, golden data, process and domain design" },
    { a: "Platform", b: "Keep the lights on", c: "A platform with golden paths, error budgets and a cost line teams can read" },
    { a: "Data", b: "Build pipelines", c: "Make the firm machine-readable — and model the knowledge agents traverse" },
  ];
  s.addText("TODAY", { x: M + 2.9, y: 1.95, w: 3.6, h: 0.25, fontSize: 10, fontFace: SANS, color: MUTED, charSpacing: 2, isTextBox: true, margin: 0 });
  s.addText("BY END-2027", { x: M + 6.9, y: 1.95, w: 4.6, h: 0.25, fontSize: 10, fontFace: SANS, color: ACCENT, charSpacing: 2, isTextBox: true, margin: 0 });
  rows.forEach((r, i) => {
    const y = 2.35 + i * 1.02;
    s.addShape(p.ShapeType.line, { x: M, y: y - 0.1, w: W, h: 0, line: { color: RULE, width: 0.75 } });
    s.addText(r.a, { x: M, y: y + 0.12, w: 2.7, h: 0.4, fontSize: 17, fontFace: SERIF, color: INK, isTextBox: true, margin: 0 });
    s.addText(r.b, { x: M + 2.9, y: y + 0.15, w: 3.7, h: 0.6, fontSize: 13, fontFace: SANS, color: MUTED, isTextBox: true, margin: 0 });
    s.addText(r.c, { x: M + 6.9, y: y + 0.1, w: 4.7, h: 0.7, fontSize: 13, fontFace: SANS, color: INK, isTextBox: true, margin: 0 });
  });
  s.addText("The honest part: if your output is a document nobody executes, that job is shrinking. You will get the training, the time and a path — but I am not going to pretend it isn't happening.", {
    x: M, y: 6.5, w: 11.6, h: 0.7, fontSize: 14, fontFace: SANS, color: MID, italic: true, isTextBox: true, margin: 0
  });
  notes(s, "This is the slide people will remember. Do not rush it. Look at the BA population when you say the honest part — they already know, and saying it first is what earns trust for everything else.");
}

// =========================================================
// 8 — PODS
// =========================================================
{
  const s = lightSlide();
  kicker(s, "How we will work");
  title(s, "Small teams. Wide ownership. Registered agents.");
  s.addShape(p.ShapeType.rect, { x: M, y: 2.05, w: 5.5, h: 3.3, fill: { color: PAPER } });
  s.addText("4–6 people", { x: M + 0.4, y: 2.3, w: 4.7, h: 0.55, fontSize: 30, fontFace: SERIF, color: INK, isTextBox: true, margin: 0 });
  s.addText([
    { text: "Product owner — value", options: { bullet: true, breakLine: true } },
    { text: "Tech lead — correctness, holds the release key", options: { bullet: true, breakLine: true } },
    { text: "2–4 product engineers who build and run", options: { bullet: true, breakLine: true } },
    { text: "Design, data, platform drawn in from chapters", options: { bullet: true } },
  ], { x: M + 0.4, y: 3.05, w: 4.7, h: 2.0, fontSize: 13, fontFace: SANS, color: MID, paraSpaceAfter: 6, isTextBox: true, margin: 0 });

  s.addShape(p.ShapeType.rect, { x: M + 5.9, y: 2.05, w: 5.7, h: 3.3, fill: { color: INK } });
  s.addText("3–5 agents", { x: M + 6.3, y: 2.3, w: 4.9, h: 0.55, fontSize: 30, fontFace: SERIF, color: PAPER, isTextBox: true, margin: 0 });
  s.addText([
    { text: "Each with a name, a mandate and a limit", options: { bullet: true, breakLine: true } },
    { text: "Its own identity — never a shared account", options: { bullet: true, breakLine: true } },
    { text: "An autonomy tier it earns by evidence", options: { bullet: true, breakLine: true } },
    { text: "And one of you accountable for it", options: { bullet: true } },
  ], { x: M + 6.3, y: 3.05, w: 4.9, h: 2.0, fontSize: 13, fontFace: SANS, color: "CFCCC4", paraSpaceAfter: 6, isTextBox: true, margin: 0 });

  s.addText("An assistant suggesting code is a tool. The same model opening a pull request is an actor — and actors get registered.", {
    x: M, y: 5.75, w: 11.6, h: 0.7, fontSize: 17, fontFace: SERIF, color: ACCENT, italic: true, isTextBox: true, margin: 0
  });
  notes(s, "The cap is five owned agents per team. Explain why: it is not bureaucracy, it is the honest limit of what four to six people can actually supervise. That limit is the real constraint on speed — not the models.");
}

// =========================================================
// 9 — THE EXPERIMENT
// =========================================================
{
  const s = lightSlide();
  kicker(s, "What happens next");
  title(s, "Three pilots. Six months. One decision.");
  const pil = [
    { n: "01", h: "Trading operations", d: "Where the economics case is made or lost" },
    { n: "02", h: "A book of record", d: "Where the controls actually bite" },
    { n: "03", h: "Intelligence Platform", d: "We eat our own cooking first" },
  ];
  pil.forEach((c, i) => {
    const w = (W - 0.7) / 3;
    const x = M + i * (w + 0.35);
    s.addShape(p.ShapeType.rect, { x, y: 2.1, w, h: 2.5, fill: { color: PAPER } });
    s.addText(c.n, { x: x + 0.35, y: 2.35, w: 1.2, h: 0.5, fontSize: 26, fontFace: SERIF, color: ACCENT, isTextBox: true, margin: 0 });
    s.addText(c.h, { x: x + 0.35, y: 3.0, w: w - 0.7, h: 0.5, fontSize: 17, fontFace: SERIF, color: INK, isTextBox: true, margin: 0 });
    s.addText(c.d, { x: x + 0.35, y: 3.6, w: w - 0.7, h: 0.8, fontSize: 13, fontFace: SANS, color: MID, isTextBox: true, margin: 0 });
  });
  s.addShape(p.ShapeType.rect, { x: M, y: 4.95, w: W, h: 1.35, fill: { color: PAPER2 } });
  s.addText("We have already written down what would make us stop.", {
    x: M + 0.4, y: 5.12, w: 11, h: 0.4, fontSize: 16, fontFace: SERIF, color: INK, isTextBox: true, margin: 0
  });
  s.addText("Cycle time unchanged · change-failure rate above baseline · the release gate routinely bypassed · or a pilot that only worked because it had our three best engineers. Written before, these are conclusions. Written after, they are excuses.",
    { x: M + 0.4, y: 5.58, w: 11.4, h: 0.6, fontSize: 12.5, fontFace: SANS, color: MID, isTextBox: true, margin: 0 });
  notes(s, "Invite people to volunteer. Say that a pilot that fails honestly is more useful to the firm than one that succeeds because of heroics — and that nobody's career suffers from a pilot that produced a clear negative result.");
}

// =========================================================
// 10 — SEQUENCE
// =========================================================
{
  const s = lightSlide();
  kicker(s, "The order of operations");
  title(s, "We do not reorganise first.");
  const gates = [
    { g: "GATE 1", h: "Visibility", d: "Every agent known and owned" },
    { g: "GATE 2", h: "Exposure", d: "Our books readable by machine" },
    { g: "GATE 3", h: "Assurance", d: "Evaluations running in production" },
    { g: "GATE 4", h: "Structure", d: "Only now do we change the org" },
  ];
  gates.forEach((c, i) => {
    const w = (W - 0.9) / 4;
    const x = M + i * (w + 0.3);
    const dark = i === 3;
    s.addShape(p.ShapeType.rect, { x, y: 2.2, w, h: 2.5, fill: { color: dark ? INK : PAPER } });
    s.addText(c.g, { x: x + 0.3, y: 2.45, w: w - 0.5, h: 0.3, fontSize: 10, fontFace: SANS, color: dark ? "CFCCC4" : ACCENT, charSpacing: 1.8, isTextBox: true, margin: 0 });
    s.addText(c.h, { x: x + 0.3, y: 2.85, w: w - 0.5, h: 0.5, fontSize: 21, fontFace: SERIF, color: dark ? PAPER : INK, isTextBox: true, margin: 0 });
    s.addText(c.d, { x: x + 0.3, y: 3.5, w: w - 0.5, h: 0.9, fontSize: 13, fontFace: SANS, color: dark ? "CFCCC4" : MID, isTextBox: true, margin: 0 });
  });
  s.addText("Most firms reorganised first and are now retrofitting the controls. Changing boxes before the capability exists just renames people.", {
    x: M, y: 5.3, w: 11.6, h: 0.8, fontSize: 17, fontFace: SERIF, color: INK, isTextBox: true, margin: 0
  });
  notes(s, "This protects people. Say that explicitly: gate-sequencing means nobody's job changes on a slide before the thing that makes it work actually exists.");
}

// =========================================================
// 11 — COMMITMENTS
// =========================================================
{
  const s = darkSlide();
  kicker(s, "How to hold me to it", "C9A227");
  s.addText("Seven commitments. Published quarterly.", {
    x: M, y: 0.62, w: W, h: 0.9, fontSize: 34, fontFace: SERIF, color: PAPER, isTextBox: true, margin: 0
  });
  const cm = [
    "90% of our books machine-readable by end-2027",
    "Zero unknown agents, verified quarterly",
    "Provenance on every figure that leaves the firm",
    "All 180 of us shipping with an agent by mid-2027",
    "Half of change with no human first draft by 2028 — with quality held",
    "Headcount neutral",
    "Cost per resolved task falling, published every quarter",
  ];
  cm.forEach((t, i) => {
    const y = 1.85 + i * 0.66;
    s.addText(String(i + 1).padStart(2, "0"), {
      x: M, y: y, w: 0.6, h: 0.4, fontSize: 15, fontFace: SERIF, color: "C9A227", isTextBox: true, margin: 0
    });
    s.addText(t, { x: M + 0.75, y: y - 0.02, w: 10.8, h: 0.45, fontSize: 16, fontFace: SANS, color: PAPER, isTextBox: true, margin: 0 });
  });
  notes(s, "Commitment four is the one that matters to this room — it says everyone, not the enthusiasts. Commitment six is the one that matters to their families. Commitment seven is how the firm judges whether we were right.");
}

// =========================================================
// 12 — CLOSE
// =========================================================
{
  const s = darkSlide();
  s.addText("The firms that win this\nwill not be the ones with the best tools.", {
    x: M, y: 1.9, w: 11.2, h: 1.8, fontSize: 38, fontFace: SERIF, color: PAPER, lineSpacing: 48, isTextBox: true, margin: 0
  });
  s.addText("They will be the ones whose people knew what they were allowed to change,\nand were trusted to change it.", {
    x: M, y: 3.95, w: 11.2, h: 1.2, fontSize: 22, fontFace: SERIF, color: "C9A227", italic: true, lineSpacing: 32, isTextBox: true, margin: 0
  });
  s.addShape(p.ShapeType.line, { x: M, y: 5.6, w: 2.2, h: 0, line: { color: ACCENT, width: 1.5 } });
  s.addText("Questions — and I would rather have the hard ones now than in the corridor.", {
    x: M, y: 5.85, w: 11, h: 0.5, fontSize: 15, fontFace: SANS, color: MUTED, isTextBox: true, margin: 0
  });
  notes(s, "Take every question. If you don't know, say so and name who will answer by when. Budget at least 5 of the 20 minutes for this — the Q&A is the presentation.");
}

p.writeFile({ fileName: "/home/claude/jonction-townhall.pptx" }).then(() => console.log("written"));
