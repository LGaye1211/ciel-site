# Jonction workspace

Source for the Pictet Asset Management technology target operating model and
its companion documents. Everything here is text; the PDFs and decks are
generated or opened directly.

**Read `CLAUDE.md` first** — it carries the context, the settled vocabulary,
the house style and the open items. `DECISIONS.md` records what was chosen,
what was rejected, and the two things that were corrected after challenge.

## Artefacts

| Artefact | Audience | Source | Build |
|---|---|---|---|
| Target operating model (~35pp) | Architecture Board, ExCo | `src/tom/` | `bash build/build.sh tom` |
| Loops & Graphs — business managers' guide (~45pp) | Business middle managers | `src/guide/` | `bash build/build.sh guide` |
| The Pod Manual (~31pp) | Delivery pods | `src/pod/` | `bash build/build.sh pod` |
| Roles — who does what, who to rely on (3pp) | Both sides of the house | `src/roles/` | `bash build/build.sh roles` |
| Naming standard NS-1 (4pp) | Anyone registering anything | `src/standards/` | `bash build/build.sh naming` |
| `pam-jonction` — 21 skills | Cowork and Claude Code users | `skills/pam-jonction/` | `bash build/check-skills.sh` |

### Decks — hand-maintained HTML, no build step

| Deck | Audience | Slides |
|---|---|---|
| `src/decks/board.html` | Board of Directors | 11 |
| `src/decks/chairman.html` | Board chairman, one-to-one | 4 |
| `src/decks/townhall-pam.html` | The whole firm | 10 |
| `src/decks/townhall-technology.html` | The ~180-person function | 16 |
| `src/decks/function-investment.html` | Investment Management & Research | 10 |
| `src/decks/function-distribution.html` | Distribution, Sales & Marketing | 10 |
| `src/decks/function-operations.html` | Investment Operations | 10 |
| `src/decks/function-finance.html` | Finance & Oversight | 10 |
| `src/decks/function-risk.html` | Risk, Compliance & Legal | 10 |

Open in a browser. ← → navigate · **N** speaker notes · **F** fullscreen · print for PDF.
`src/decks/jonction-townhall.html` is superseded by `townhall-technology.html` and kept
for the record (see DECISIONS.md D21).

The guide and the pod manual are a matched pair: they describe the same twelve
weeks, on the same worked example (reconciliations), from the business side and
the engineering side. Figures are internally consistent across both — changing
one means changing the other.

## Setup

```bash
pip install weasyprint pypdf pillow --break-system-packages
bash build/build.sh
```

Fonts ship in `src/fonts/` (Spectral, OFL). The build reports page counts and
warns about sparse pages — see `CLAUDE.md` §7 for what causes them.

## Working conventions

- Edit body parts, never `out/`.
- Decks are hand-maintained HTML with a fixed 1280×720 canvas; there is no
  slide framework and none is wanted. Each deck is self-contained and portable.
  `build/deck-engine.html` + `build/deck-footer.html` are the starting template for a
  new one, and `bash build/decks.sh <slides-dir>` reassembles them from slide bodies.
- Skills follow the naming standard they ship: `bash build/check-skills.sh` enforces it.
- Any substantive change goes in `DECISIONS.md` as a new entry. Append only.
- Before circulating anything, check `CLAUDE.md` §11 — several numbers in the
  documents are authored placeholders rather than measured facts.
