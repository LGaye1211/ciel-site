# Jonction workspace

Source for the Pictet Asset Management technology target operating model and
its companion documents. Everything here is text; the PDFs and decks are
generated or opened directly.

**Read `CLAUDE.md` first** — it carries the context, the settled vocabulary,
the house style and the open items. `DECISIONS.md` records what was chosen,
what was rejected, and the two things that were corrected after challenge.

## Artefacts

| Artefact | Audience | Source | Build |
|---|---|---|---|
| Target operating model (35pp, with the “How the model works” figure) | Architecture Board, ExCo | `src/tom/` | `bash build/build.sh tom` |
| Loops & Graphs — business managers' guide (~45pp) | Business middle managers | `src/guide/` | `bash build/build.sh guide` |
| The Pod Manual (~31pp) | Delivery pods | `src/pod/` | `bash build/build.sh pod` |
| Roles — who does what, who to rely on (4pp) | Both sides of the house | `src/roles/` | `bash build/build.sh roles` |
| Naming standard NS-1 (4pp) | Anyone registering anything | `src/standards/` | `bash build/build.sh naming` |
| Jonction on one page (1pp) | ExCo, Board, anyone new to it | `src/onepager/` | `bash build/build.sh onepager` |
| The charter set — index + 16 charters (3pp each): four platforms, CTOO office, four chapters, seven Agentic & Cloud Services teams including Architecture; mission, vision, KPIs, automatic capture, first ninety days | Every owner named in the TOM | `src/charters/data_*.py` (content) + `build/charters.py` (template) | `bash build/build.sh charters` |
| Breakthrough experiments — technology town hall (3 slides, 16:9 PDF) | The technology function | `src/experiments/` | `bash build/build.sh experiments` |
| The AI-native powerhouse — research brief (6pp, the source of truth for the ten areas and the four breakthrough experiments): ten transformation areas, end-2027 objectives, evidence from April–September 2026, dated vs gated | CTOO, ExCo | `src/research/` | `bash build/build.sh research` |
| AI-native on two pages: the overview, and breakthrough experiments where each platform lead rebuilds one of its own duties agent-first (generated from the brief) | Platform leads, ExCo | `build/twopager.py` | `bash build/build.sh research` |
| Intent to Outcome — orchestration and communication (8pp): the dual key (Business Outcome Owner + Tech Product Builder), the executable spec, nine practices, OKRs and the health dashboard, the CTOO communication system and rhythm | Extended leadership team | `src/i2o/i2o.html` | `bash build/build.sh i2o` |
| `pam-jonction` — 23 skills | Cowork and Claude Code users | `skills/pam-jonction/` | `bash build/check-skills.sh` |

### Decks — hand-maintained HTML, no build step

| Deck | Audience | Slides |
|---|---|---|
| `src/decks/board.html` | Board of Directors | 11 |
| `src/decks/chairman.html` | Board chairman, one-to-one | 4 |
| `src/decks/townhall-pam.html` | The whole firm | 10 |
| `src/decks/townhall-technology.html` | The technology function | 16 |
| `src/decks/function-investment.html` | Investment Management & Research | 10 |
| `src/decks/function-distribution.html` | Distribution, Sales & Marketing | 10 |
| `src/decks/function-operations.html` | Investment Operations | 10 |
| `src/decks/function-finance.html` | Finance & Oversight | 10 |
| `src/decks/function-risk.html` | Risk, Compliance & Legal | 10 |
| `src/decks/intent-to-outcome.html` | Extended leadership team: Intent to Outcome, decisions requested | 11 |
| `src/decks/keynote-jonction.html` | PAM Tech town hall keynote, 30 minutes: CEO opening (3 min), then the why, the axes, chapters, business enablement and Agentic & Cloud Services. Pictet style; works on phones (scrolling reader) and tablets (swipe, tap) | 12 |
| `src/decks/keynote-jonction-minto.html` | Same keynote, Minto version: answer first, SCQA why, action titles, three pillars (people, platform, partnership), answer restated at the close | 12 |
| `out/jonction-townhall-keynote.pptx` | The keynote as PowerPoint: walk-in video loop, then the 12 slides with an animation on each (GIFs play by themselves), Pictet style, speaker notes | 13 |

Open in a browser. ← → navigate · **N** speaker notes · **F** fullscreen · print for PDF.
`src/decks/jonction-townhall.html` is superseded by `townhall-technology.html` and kept
for the record (see DECISIONS.md D21).

The guide and the pod manual are a matched pair: they describe the same twelve
weeks, on the same worked example (reconciliations), from the business side and
the engineering side. Figures are internally consistent across both — changing
one means changing the other.

## Setup

```bash
pip install weasyprint pypdf pillow --break-system-packages
bash build/build.sh
```

Fonts ship in `src/fonts/` (Spectral, OFL). The build reports page counts and
warns about sparse pages — see `CLAUDE.md` §7 for what causes them.

## Working conventions

- Edit body parts, never `out/`.
- Decks are hand-maintained HTML with a fixed 1280×720 canvas; there is no
  slide framework and none is wanted. Each deck is self-contained and portable.
  `build/deck-engine.html` + `build/deck-footer.html` are the starting template for a
  new one, and `bash build/decks.sh <slides-dir>` reassembles them from slide bodies.
- Skills follow the naming standard they ship: `bash build/check-skills.sh` enforces it.
- Any substantive change goes in `DECISIONS.md` as a new entry. Append only.
- Before circulating anything, check `CLAUDE.md` §11 — several numbers in the
  documents are authored placeholders rather than measured facts.
