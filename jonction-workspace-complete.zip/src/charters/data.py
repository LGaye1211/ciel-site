# Aggregator for the charter set. Order is the order of the index and of the zip.
from data_platforms import PLATFORMS
from data_chapters import CHAPTERS
from data_intelligence import INTELLIGENCE

CHARTERS = PLATFORMS + CHAPTERS + INTELLIGENCE

# The instrumentation spine, common to every charter: sources → one warehouse → three surfaces.
SPINE = {
    "warehouse": "Snowflake — one warehouse, one definition per KPI, tagged by team · lane · use case · tier",
    "surfaces": ["Grafana — owners, service levels, alerts, daily",
                 "CTOO dashboard — the seven commitments, monthly",
                 "Quarterly note — generated from the same tables"],
}

GROUPS = [("Platforms and the CTOO office", PLATFORMS),
          ("Chapters", CHAPTERS),
          ("Intelligence Platform teams", INTELLIGENCE)]
