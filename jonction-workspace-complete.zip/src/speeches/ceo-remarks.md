# Jonction · Technology town hall · CEO remarks (draft)

**Speaker:** Ray Sagayam, CEO, Pictet Asset Management
**Slot:** slide 4, straight after the why (both keynote versions) · **Length:** about 3 minutes, ~400 words
**Status:** draft for Ray to make his own. Every word should be his; change anything that does not sound like him.
**Sources** for the two industry facts (also in the research brief): Stanford AI Index, Apr 2026 (agent task success); McKinsey State of AI, Aug 2026 (the top 6% redesigned whole workflows).

---

**[0:00 · Why I am here]**

Good morning. I asked Laurent for a few minutes today, because what he is about to describe matters to the whole firm, and I want you to hear that from me.

Laurent told you about tunnels built for a city that did not yet exist. This firm has thought that way since 1805. We have always built for the long term.

**[0:30 · What AI is doing to our industry]**

Let me be direct about what is happening around us. AI is changing our industry at a speed none of us has seen before. It is reaching every part of what we do: how we research, how we build portfolios, how we serve clients, how we run our operations.

Agents now carry out real work. In the latest Stanford AI Index, the share of tasks they complete successfully rose from one in five to more than three in four.

And here is the uncomfortable truth: every firm in our industry has access to the same models. AI levels access. It will not level execution.

**[1:15 · Why engineering decides the race]**

So where will firms separate? McKinsey found that the leaders, around six per cent of companies, are the ones that redesigned how they work from end to end. Buying tools is the easy part.

The advantage comes from the engineering underneath: our data, our knowledge made readable by machines, controls that our clients and our regulators can trust, and a way of working that turns an idea into a safe result in days.

None of that can be bought off the shelf. It has to be built, by people who know this firm. That is you.

**[2:00 · What I expect, and what I promise]**

This is why technology sits at the heart of our transformation, at the junction with the business. That is what Jonction means.

I want PAM to be early. In engineering, being early compounds: every month we spend building the foundations, the gap with those who wait grows wider.

And I want to be clear about how we do it: with the people in this room. Your knowledge of our systems, our clients and our risks is exactly what makes AI safe and useful here. Laurent and his team have my full support, and so do you.

**[2:40 · Hand-over]**

Our clients trust us with their assets for the long term. Let us earn that trust again, by building now what the next generation of our industry will run on.

Laurent, over to you.

---

**Delivery notes**
- Best in person; second best a 60 to 90 second cut recorded on video (keep 0:30 to 2:40, shorten the opening and the hand-over).
- The two numbers are the only statistics: say them slowly. If Ray prefers no numbers, drop the Stanford sentence and keep "Agents now carry out real work."
- **Timing in the keynote:** the slide 4 slot is 90 seconds. The full 3 minutes adds 90 seconds:
  take it from the questions, or shorten the evolution slide.
- **If Ray opens the town hall instead** (before Laurent's story): replace the second paragraph with
  "This firm has thought in generations since 1805. We have always built for the long term, and
  today we start building again." End with "Laurent will now tell you what we will build, and how."
  Then drop slide 4 from the keynote.
- Laurent picks up with: "Thank you, Ray. Before the what and the how, what this means for each of you."
