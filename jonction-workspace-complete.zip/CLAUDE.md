# CLAUDE.md — Jonction workspace

Context for continuing work on the Jonction target operating model and its
companion documents. Read this file first, then `DECISIONS.md` before changing
anything substantive.

---

## 1. Who and where

- **Owner:** Laurent Gaye, CTOO, Pictet Asset Management (PAM), Geneva.
- **Audience for these documents:** Architecture Board, Executive Committee,
  Board of Directors, the ~180-person technology function, and business-side
  middle managers.
- **PAM is an asset manager**, not a wealth manager. No relationship managers,
  no RM cockpit, no private-banking framing. Institutional clients and
  distributors. Do not import Pictet Wealth Management language.

## 2. What Jonction is

The target operating model for PAM's technology function under agentic AI.
Named after the Geneva quarter where the Rhône and the Arve meet. Internal
name only — never used externally, and there is no external announcement.

**Architecture vocabulary (settled, do not re-litigate):**
- **Systems of record** — the books: IBOR, ABOR, client, counterparty,
  mandates & restrictions, product, performance, approved content,
  distribution data.
- **Systems of engagement** — Cowork, Claude Code, portals, sales and
  marketing tools.
- **Systems of action** — order routing, pre-trade compliance, Themis
  (thematic investing management), reconciliation, KYC refresh, content
  assembly.
- **Control plane** — registry, gateway, non-human identity, evaluations,
  cost attribution, provenance. Owned by the **Intelligence Platform**.

**The binding rule (corrected once already — see DECISIONS.md):**
> Every actor writes only through the record's own contract, only forward,
> and never to the rules that constrain it.

Three parts: writes take the authorised path; originating forward is normal
while retroactive amendment is human-approved; nothing writes to the rules it
is judged by. **These are capabilities, not applications** — one platform
usually spans all three layers.

**Five controls per book:** read-restricted, contract-only, amend-restricted,
rules, provenance-required.

## 3. Organisation (settled)

- **Leadership team, as today (D27):** the four platform leads (Investment, Client,
  Corporate, Intelligence), the head of the CTOO office, and the head of operations.
  Never write "five direct reports".
- **Four chapters, five leads, reporting DIRECTLY to the CTOO** (not the CTOO office):
  Software Engineering · **Business Analysis & FDE** (co-led by a business analysis
  lead, correctness, and an FDE lead, forward-deployed engineering; designers sit with
  the analysts) · Platform & Reliability Engineering · Data & Knowledge Engineering.
  Never write "Business Analysis & Design" any more.
- **Managing the chapter leads:** a weekly **extended leadership team** (leadership
  team + the chapter leads; one hour, fixed agenda, one written note, CTOO office holds
  the pen) and a **quarterly one-to-one with the CTOO**, the only one-to-one, against
  the craft charter. Chapter leads present their charters at the quarterly platform
  review. They still have no delivery authority.
- **Architecture** sits inside the Intelligence Platform as its own line, like AI
  Assurance: head of architecture, architects embedded half-time, chairs the
  Architecture Board, keeps the vendor-agent veto; standards bind every platform;
  escalation only to the CTOO. The Intelligence Platform has ten activity lines.
- **CTOO office** holds: three delivery coaches, the product owner guild, portfolio &
  finance, vendor-agent governance, the dashboard and quarterly note on the ten areas,
  the June 2027 breakthrough decisions, the extended leadership team secretariat.
  Kicker: PORTFOLIO · NEUTRALITY.
- **AI Assurance** sits inside the Intelligence Platform as its own line
  (D23, reversing D4). Independent **by charter, not by reporting line**: a
  written veto the platform lead cannot overrule, escalation only to the
  CTOO, no adoption target in its objectives, Risk as second line, Internal
  Audit sampling verdicts. Pods still never see the golden sets. Do not
  write "independent of Intelligence" anywhere.
- **Seventeen products.** Full list in the TOM Appendix I. Product names appear
  **only** in that appendix — the body of the TOM refers to layers and
  capabilities, never to product names. This was an explicit correction.
- **Intelligence Platform products** (renamed from the current fourth
  platform): Model & Agent Platform (was AI Platform), Control Plane (new),
  Analytics & Knowledge Tools (was Analytics Tools), Cloud & Runtime Services
  (was Cloud Ops Services), Fluency & Enablement (was Enabling Teams).
- **Scrum masters abolished** as a job; **testing dissolved** as a function.
- **FDEs** deployed in business teams inside the business platforms: solid line to the
  platform lead, dotted line to the FDE lead (Business Analysis & FDE), 90-day rule.
- **Intent to Outcome (D28) — product ownership:** product owners STAY in technology
  and work as **Tech Product Builders** (definition, architecture coherence, agent
  supervision, prototypes; title changes with job families at Gate 4). Each value
  stream has a **Business Outcome Owner** in the business (outcome KPI, what and why,
  co-signs the executable spec and the OKRs; manages no technology people). The
  **dual key** = Outcome Owner (business) + Product Builder (technology); the tech
  lead keeps the release key; AI Assurance the gate. NEVER write that product owners
  move to or report into the business. Conditions: dual key written, capacity tax,
  product owner guild, appointments (business head names the Outcome Owner, CTOO
  approves the Product Builder), visible cost (outcome budget + token budget).
- **Intent to Outcome — the rest:** the executable spec is the contract (intent,
  constraints, acceptance tests, evals, controls, risk tier; co-signed); nine
  practices A1–A9 (TOM §07 table); demo before deck; the Agent Factory with six to
  ten Superbuilders in Model & Agent Platform; three lighthouse value streams from
  January 2027; three-level OKRs (no individual OKRs, never AI usage) with the
  health dashboard kept separate; the CTOO communication system (Agent Speedrun,
  Build Log, Context Essay, Ask Laurent, Tech Oracle, Top 5 Signals, audio briefing,
  Fluency Ladder and Builder Board, Frontier Time, decision latency). Detail:
  `src/i2o/i2o.html`. Never import the source proposal's headcount or sizing.

## 4. The ten transformation areas (replace the seven commitments, D26)

North star: **Built for agents and humans. Built by agents and humans.**
Four lines said out loud: *Five times faster, at least as safe* · *Every team has agents
on its roster* · *Our knowledge, readable by machines* · *Same people, a new craft*.

| # | Area | Date or gate |
|---|---|---|
| 01 | Agent-native delivery (100% agent-first draft, ≥80% agent-authored, five times faster) | End-2027 |
| 02 | Verification at machine speed (harness everywhere, CFR ≤ 2025 while throughput doubles) | Mid-2027 |
| 03 | Small teams, large fleets (four breakthrough experiments now; pods only at Gate 4) | Gated |
| 04 | Core processes rebuilt around agent teammates (10 by mid-2027, 25 by end-2027) | End-2027 |
| 05 | The firm's knowledge, machine-readable (90% of key books, provenance on every figure) | End-2027 |
| 06 | The Intelligence Platform (keys tagged, one gateway, an agent in under a day) | 1 Jan 2027 · mid-2027 |
| 07 | Trust as a competitive edge (zero unknown agents, ISO/IEC 42001, AI Act 2 Dec 2027) | End-2027 |
| 08 | AI economics in the P&L (cost per resolved task falling, cost per change −40%) | End-2027 |
| 09 | The product model, reinforced: "one product, every force" | 1 Jan 2027 · end-2027 |
| 10 | Same people, a new craft (headcount unchanged by AI; certified by shipping mid-2027) | End-2027 |

Never write "the seven commitments" or "commitment N" again. The old numbers live on
inside the areas: books and provenance → 05, unknown agents → 07, shipped by mid-2027 →
10, agent-first draft and CFR → 01/02, headcount → 10, cost per resolved task → 08.
Evidence for every objective: `src/research/ainative.html` (the brief, source of truth).
Say **agent teammates**, never "digital colleagues".

**Performance definition** (Laurent's own, already shared with the teams):
`(fast value delivery × production stability & security) ÷ cost`. The terms
multiply — a stability failure zeroes value rather than subtracting from it.

## 5. Breakthrough experiments, and the pod

Four cells, one per platform lead, each rebuilding one of the platform's OWN duties
agent-first from a blank sheet (the how, never a service to internal clients):
Investment · build and release (24-hour cycle, a pod, on a product touching a book of
record) · Client · decide what to build (agent-first intake) · Corporate · modernise and
decommission (one legacy application) · Intelligence · run and operate (agents as first
responders). Six rules: blank sheet · agents first, people on judgment · owned by the
platform lead, ring-fenced cell of four to six · old and new side by side · four common
measures · tenfold or fold. January–June 2027; one decision each in June 2027.
Ceiling of four. Reconciliation is NOT a pilot: it is area 04's first loop and the
worked example. A pod is 4–6 people + 3–5 registered agents, cap of five owned agents;
pods become the delivery unit only at Gate 4. Seating is dated (waves from Q2 2027),
no longer part of Gate 4.

## 6. Repository map

```
src/
  tom/          head.html + body.html        → the target operating model PDF
  guide/        head2.html + guide1–3.html   → business managers' guide PDF
  pod/          head3.html + pod1–3.html     → the pod manual PDF
  roles/        roles.html                   → 4-page role book (self-contained HTML + PDF)
  standards/    naming.html                  → naming standard NS-1 (self-contained + PDF)
  onepager/     onepager.html                → objectives, design choices, org chart, timeline on one A4
  experiments/  experiments.html             → 3-slide 16:9 PDF: the four breakthrough experiments, one per platform
  i2o/          i2o.html                     → Intent to Outcome: orchestration and communication (companion to TOM §07)
  research/     breakthrough.html            → 2-page version, GENERATED by build/twopager.py from ainative.html; never edit by hand
  research/     ainative.html                → 6-page research brief: the source of truth for the ten areas (D26)
  charters/     data.py + data_platforms.py + data_chapters.py + data_intelligence.py
                                              → content of the 16 charters (dicts; schema in build/charters.py)
  decks/        board.html                    → 11-slide Board deck
                chairman.html                 → 4-slide chairman 1-2-1
                townhall-pam.html             → 10-slide firm-wide town hall
                townhall-technology.html      → 16-slide technology town hall
                intent-to-outcome.html        → 11-slide deck for the extended leadership team (D28)
                function-{investment,distribution,operations,finance,risk}.html
                                              → 10 slides each
                jonction-townhall.html        → superseded by townhall-technology
                townhall-pptx.js              → older pptx generator (superseded)
  fonts/        Spectral TTFs used by the PDFs
skills/
  pam-jonction/ .claude-plugin/plugin.json + skills/<name>/SKILL.md × 21
build/          build.sh          renders all PDFs
                charters.py       template + renderer for the charter set → out/charters/
                decks.sh          reassembles decks from slide bodies
                check-skills.sh   validates the skill plugin against NS-1
                deck-engine.html  the shared deck template (head + styles)
                deck-footer.html  the shared deck template (controls + script)
out/            generated artefacts (not source)
```

Each PDF is assembled by concatenating a `head` file (CSS + frontmatter) with
body parts, then rendering with WeasyPrint. **Edit the body parts, never the
generated PDF.**

## 7. How to build

```bash
bash build/build.sh          # renders all PDFs into out/ (six documents + out/charters/)
bash build/build.sh tom      # one of: tom | guide | pod | roles | naming | onepager | experiments | research | i2o | charters
python3 build/charters.py aia se   # one or more charters by id
bash build/check-skills.sh   # validates the 23 skills against NS-1
```

Decks need no build. `bash build/decks.sh <slides-dir>` reassembles them only when the
shared engine changes.

Requires `weasyprint`, `pypdf`, `pdftoppm` (poppler) and Pillow for QA.
Install: `pip install weasyprint pypdf pillow --break-system-packages`

**Always visually QA after a render.** WeasyPrint silently produces
near-empty pages when a `.two` flex block cannot fit. The check:

```bash
python3 - <<'EOF'
from pypdf import PdfReader
r = PdfReader('out/jonction-tom.pdf')
for i, p in enumerate(r.pages, 1):
    t = (p.extract_text() or '').strip()
    if len(t) < 400 and i > 1:
        print('sparse', i, len(t))
EOF
```

Fix sparse pages by converting the offending `.two` block to
`style="column-count:2;column-gap:10mm"` (breakable across pages) or by
tightening copy. Do not fix them by shrinking font sizes.

## 8. House style — enforced

**Visual.** Ivory cover (`#f7f5f0`), ink (`#1c1c1a`), one bronze accent
(`#7a5c2e`), gold only on dark slides (`#c9a227`). Spectral Light for display,
a Helvetica-class sans for body. Hairline rules. No logo, no stock imagery,
no gradients, no icons.

**Written.** Plain declarative sentences. No em-dash asides stacked in threes,
no "not X but Y" constructions, no colon-then-reveal, no invented labels in
scare quotes. British spelling. Numbers with dates. Where a claim comes from
research, attribute it in an appendix rather than mid-sentence.

**Tone.** This is for a Board and for 180 professionals who have sat through
transformation programmes before. Candour outperforms polish: state failure
conditions before benefits, name what is uncertain, and record what was
rejected alongside what was chosen.

**Also:** write "the CTOO office", never "the office" alone. "Key books of
record". "Thematic management in Themis", never maintenance.

**Banned:** "AI slop" — generic transformation narrative, vision statements,
adjective stacks, and any sentence that would survive being copied into
another firm's deck unchanged.

## 9. Anti-metrics (stated in the documents, keep them)

Never propose as measures: seats activated, prompts sent, lines of generated
code, story points, headcount saved.

## 10. Facts that are established — don't re-derive

- ~180 people in the technology function — **context only. The figure is never
  stated in any document or deck**; write "the technology function" or
  "everyone in technology".
- Snowflake is the warehouse; LiteLLM is the sole gateway; Grafana and
  Prometheus for telemetry; Jira for initiative tracking only.
- Cowork ready to deploy firm-wide; ~200 kUSD/month gateway cap.
- Roughly a third of business users already equipped with Claude Code
  securely; primitives built for Salesforce, Microsoft Graph, Snowflake,
  Bloomberg, web search.
- Themis is the thematic investing management tool; it sits in Investment
  Research. Theme criteria are **rules** — Themis writes constituents, never
  the criteria.
- Reconciliation is the worked example throughout the guide and the pod
  manual. Its figures are illustrative and internally consistent across both
  documents — if you change one, change both.

## 10b. Standards now written down

- **Naming (NS-1)** — `src/standards/naming.html`. One grammar; a closed list of twelve
  capability verbs; three rules enforced mechanically (amend/write_rule tools need an
  ADR before allow-listing, off-list verbs fail registration, untagged keys are not
  issued). Names are immutable after registration.
- **Roles** — `src/roles/roles.html`. Both sides of the house. Three roles that must be
  named before a first loop: business owner of a loop, adjudicator, named supervisor.
- **Skills** — `skills/pam-jonction/`, 21 of them, the method made runnable. No skill
  reads a golden set, by design.

## 10c. The charter set and the "How the model works" figure

- The TOM has an unnumbered section after the ten areas page: **How the model works**
  (Figure 1, a system diagram: objective → three levers → enabling layer → closeness to
  the business → the quarterly loop; then "Reading the figure"). Figures 2–4 are the
  three layers, the organisation and the timeline. Keep the numbering if you add figures.
- Sixteen charters, one per platform (4), the CTOO office, chapter (4) and Intelligence
  Platform team (7, Architecture included). Content lives in `src/charters/data_*.py` as dicts; the schema is
  `id, kind, sub, name, tagline, mission, vision, lever, owns[], not_owns[],
  interfaces[(who, what)], kpi_intro, kpis[{kpi, def, target, source, how, cadence}],
  capture, sources[(name, what)] ≤5, ninety[(title, detail)] ×4, owner, owner_note?`.
  Every charter renders to exactly 3 pages; if one spills to 4, shorten the mission or
  the owns list (the two-column blocks do not fragment across pages).
- Charter rules: KPIs are read together, never one alone; the anti-metrics line is on
  every charter; every KPI row says how it is captured automatically and from which
  event source; the AI Assurance charter keeps D23's independence clauses verbatim.
- KPI definitions are registered in the warehouse by Analytics & Knowledge Tools; a
  KPI without a query is refused. Targets are decisions (DECISIONS.md), not edits.

## 11. Open items

- The Intelligence Platform starts on 1 January 2027; the four breakthrough
  experiments start with it and decide at end-June 2027. The communication months in TOM §10
  are proposed; the order is not.
- The products and legacy application for the four experiments are not yet named.
  Empty boxes read as an intention; named products read as a decision.
- The sixth leadership seat is held by the head of operations (D27); operations keep
  their current organisation.
- Indicative sizing throughout (50/35/40/35/20 across platforms and the
  office) is authored, not measured. Replace with the real establishment.
- The three lighthouse value streams and their Business Outcome Owners are not
  yet named (candidates: investment decision support, order to settlement, fund
  reporting, client and distribution data). The 70% Speedrun target and the
  illustrative Q2 2027 OKRs are proposals until decided.
