# CLAUDE.md — Jonction workspace

Context for continuing work on the Jonction target operating model and its
companion documents. Read this file first, then `DECISIONS.md` before changing
anything substantive.

---

## 1. Who and where

- **Owner:** Laurent Gaye, CTOO, Pictet Asset Management (PAM), Geneva.
- **Audience for these documents:** Architecture Board, Executive Committee,
  Board of Directors, the ~180-person technology function, and business-side
  middle managers.
- **PAM is an asset manager**, not a wealth manager. No relationship managers,
  no RM cockpit, no private-banking framing. Institutional clients and
  distributors. Do not import Pictet Wealth Management language.

## 2. What Jonction is

The target operating model for PAM's technology function under agentic AI.
Named after the Geneva quarter where the Rhône and the Arve meet. Internal
name only — never used externally, and there is no external announcement.

**Architecture vocabulary (settled, do not re-litigate):**
- **Systems of record** — the books: IBOR, ABOR, client, counterparty,
  mandates & restrictions, product, performance, approved content,
  distribution data.
- **Systems of engagement** — Cowork, Claude Code, portals, sales and
  marketing tools.
- **Systems of action** — order routing, pre-trade compliance, Themis
  (thematic investing management), reconciliation, KYC refresh, content
  assembly.
- **Control plane** — registry, gateway, non-human identity, evaluations,
  cost attribution, provenance. Owned by the **Intelligence Platform**.

**The binding rule (corrected once already — see DECISIONS.md):**
> Every actor writes only through the record's own contract, only forward,
> and never to the rules that constrain it.

Three parts: writes take the authorised path; originating forward is normal
while retroactive amendment is human-approved; nothing writes to the rules it
is judged by. **These are capabilities, not applications** — one platform
usually spans all three layers.

**Five controls per book:** read-restricted, contract-only, amend-restricted,
rules, provenance-required.

## 3. Organisation (settled)

- **Five direct reports:** three business platform leads (Investment, Client,
  Corporate), the Intelligence Platform lead, and the head of the CTOO office.
- **Four chapters** (report to head of CTOO office): Software Engineering,
  Business Analysis & Design, Platform & Reliability Engineering,
  Data & Knowledge Engineering.
- **CTOO office** also holds: architecture (embedded half-time in platforms),
  three delivery coaches, the product owner guild, portfolio & finance,
  vendor-agent governance.
- **AI Assurance** sits inside the Intelligence Platform as its own line
  (D23, reversing D4). Independent **by charter, not by reporting line**: a
  written veto the platform lead cannot overrule, escalation only to the
  CTOO, no adoption target in its objectives, Risk as second line, Internal
  Audit sampling verdicts. Pods still never see the golden sets. Do not
  write "independent of Intelligence" anywhere.
- **Seventeen products.** Full list in the TOM Appendix I. Product names appear
  **only** in that appendix — the body of the TOM refers to layers and
  capabilities, never to product names. This was an explicit correction.
- **Intelligence Platform products** (renamed from the current fourth
  platform): Model & Agent Platform (was AI Platform), Control Plane (new),
  Analytics & Knowledge Tools (was Analytics Tools), Cloud & Runtime Services
  (was Cloud Ops Services), Fluency & Enablement (was Enabling Teams).
- **Scrum masters abolished** as a job; **testing dissolved** as a function.
- **FDEs** inside business platforms, solid line to technology, 90-day rule.
- **Product ownership:** about half the products' POs move to the business
  (engagement and action products); record, platform and control-plane
  products keep their PO in technology. Five conditions apply — dual key,
  capacity tax, PO guild, appointment veto, visible cost.

## 4. The seven commitments

1. 90% of books of record machine-readable, entitlements intact, by end-2027
2. Zero unknown agents, verified quarterly
3. Machine-verifiable provenance on every figure leaving the firm
4. Everyone in the technology function has shipped or owns something built
   with an agent by mid-2027
5. All change with no human first draft by end-2027, change-failure rate at
   or below the 2025 baseline — a standard enforced at the release gate, not
   a productivity target
6. Technology headcount does not change because of AI. What the function
   does changes; there is no plan to change its size
7. Cost per resolved task falling year on year, published quarterly

**Performance definition** (Laurent's own, already shared with the teams):
`(fast value delivery × production stability & security) ÷ cost`. The terms
multiply — a stability failure zeroes value rather than subtracting from it.

## 5. The pod experiment

Not yet adopted. Three pilots, six months, one decision: trading operations,
a product touching a book of record, and inside the Intelligence Platform.
A pod is 4–6 people + 3–5 registered agents, cap of five owned agents.
The word "pod" is earned by the pilots; until then the unit is a squad.
Stopping criteria are written down in advance.

## 6. Repository map

```
src/
  tom/          head.html + body.html        → the target operating model PDF
  guide/        head2.html + guide1–3.html   → business managers' guide PDF
  pod/          head3.html + pod1–3.html     → the pod manual PDF
  roles/        roles.html                   → 3-page role book (self-contained HTML + PDF)
  standards/    naming.html                  → naming standard NS-1 (self-contained + PDF)
  onepager/     onepager.html                → objectives, design choices, org chart, timeline on one A4
  charters/     data.py + data_platforms.py + data_chapters.py + data_intelligence.py
                                              → content of the 15 charters (dicts; schema in build/charters.py)
  decks/        board.html                    → 11-slide Board deck
                chairman.html                 → 4-slide chairman 1-2-1
                townhall-pam.html             → 10-slide firm-wide town hall
                townhall-technology.html      → 16-slide technology town hall
                function-{investment,distribution,operations,finance,risk}.html
                                              → 10 slides each
                jonction-townhall.html        → superseded by townhall-technology
                townhall-pptx.js              → older pptx generator (superseded)
  fonts/        Spectral TTFs used by the PDFs
skills/
  pam-jonction/ .claude-plugin/plugin.json + skills/<name>/SKILL.md × 21
build/          build.sh          renders all PDFs
                charters.py       template + renderer for the charter set → out/charters/
                decks.sh          reassembles decks from slide bodies
                check-skills.sh   validates the skill plugin against NS-1
                deck-engine.html  the shared deck template (head + styles)
                deck-footer.html  the shared deck template (controls + script)
out/            generated artefacts (not source)
```

Each PDF is assembled by concatenating a `head` file (CSS + frontmatter) with
body parts, then rendering with WeasyPrint. **Edit the body parts, never the
generated PDF.**

## 7. How to build

```bash
bash build/build.sh          # renders all PDFs into out/ (six documents + out/charters/)
bash build/build.sh tom      # one of: tom | guide | pod | roles | naming | onepager | charters
python3 build/charters.py aia se   # one or more charters by id
bash build/check-skills.sh   # validates the 21 skills against NS-1
```

Decks need no build. `bash build/decks.sh <slides-dir>` reassembles them only when the
shared engine changes.

Requires `weasyprint`, `pypdf`, `pdftoppm` (poppler) and Pillow for QA.
Install: `pip install weasyprint pypdf pillow --break-system-packages`

**Always visually QA after a render.** WeasyPrint silently produces
near-empty pages when a `.two` flex block cannot fit. The check:

```bash
python3 - <<'EOF'
from pypdf import PdfReader
r = PdfReader('out/jonction-tom.pdf')
for i, p in enumerate(r.pages, 1):
    t = (p.extract_text() or '').strip()
    if len(t) < 400 and i > 1:
        print('sparse', i, len(t))
EOF
```

Fix sparse pages by converting the offending `.two` block to
`style="column-count:2;column-gap:10mm"` (breakable across pages) or by
tightening copy. Do not fix them by shrinking font sizes.

## 8. House style — enforced

**Visual.** Ivory cover (`#f7f5f0`), ink (`#1c1c1a`), one bronze accent
(`#7a5c2e`), gold only on dark slides (`#c9a227`). Spectral Light for display,
a Helvetica-class sans for body. Hairline rules. No logo, no stock imagery,
no gradients, no icons.

**Written.** Plain declarative sentences. No em-dash asides stacked in threes,
no "not X but Y" constructions, no colon-then-reveal, no invented labels in
scare quotes. British spelling. Numbers with dates. Where a claim comes from
research, attribute it in an appendix rather than mid-sentence.

**Tone.** This is for a Board and for 180 professionals who have sat through
transformation programmes before. Candour outperforms polish: state failure
conditions before benefits, name what is uncertain, and record what was
rejected alongside what was chosen.

**Also:** write "the CTOO office", never "the office" alone. "Key books of
record". "Thematic management in Themis", never maintenance.

**Banned:** "AI slop" — generic transformation narrative, vision statements,
adjective stacks, and any sentence that would survive being copied into
another firm's deck unchanged.

## 9. Anti-metrics (stated in the documents, keep them)

Never propose as measures: seats activated, prompts sent, lines of generated
code, story points, headcount saved.

## 10. Facts that are established — don't re-derive

- ~180 people in the technology function — **context only. The figure is never
  stated in any document or deck**; write "the technology function" or
  "everyone in technology".
- Snowflake is the warehouse; LiteLLM is the sole gateway; Grafana and
  Prometheus for telemetry; Jira for initiative tracking only.
- Cowork ready to deploy firm-wide; ~200 kUSD/month gateway cap.
- Roughly a third of business users already equipped with Claude Code
  securely; primitives built for Salesforce, Microsoft Graph, Snowflake,
  Bloomberg, web search.
- Themis is the thematic investing management tool; it sits in Investment
  Research. Theme criteria are **rules** — Themis writes constituents, never
  the criteria.
- Reconciliation is the worked example throughout the guide and the pod
  manual. Its figures are illustrative and internally consistent across both
  documents — if you change one, change both.

## 10b. Standards now written down

- **Naming (NS-1)** — `src/standards/naming.html`. One grammar; a closed list of twelve
  capability verbs; three rules enforced mechanically (amend/write_rule tools need an
  ADR before allow-listing, off-list verbs fail registration, untagged keys are not
  issued). Names are immutable after registration.
- **Roles** — `src/roles/roles.html`. Both sides of the house. Three roles that must be
  named before a first loop: business owner of a loop, adjudicator, named supervisor.
- **Skills** — `skills/pam-jonction/`, 21 of them, the method made runnable. No skill
  reads a golden set, by design.

## 10c. The charter set and the "How the model works" figure

- The TOM has an unnumbered section after the seven commitments: **How the model works**
  (Figure 1, a system diagram: objective → three levers → enabling layer → closeness to
  the business → the quarterly loop; then "Reading the figure"). Figures 2–4 are the
  three layers, the organisation and the timeline. Keep the numbering if you add figures.
- Fifteen charters, one per platform (4), the CTOO office, chapter (4) and Intelligence
  Platform team (6). Content lives in `src/charters/data_*.py` as dicts; the schema is
  `id, kind, sub, name, tagline, mission, vision, lever, owns[], not_owns[],
  interfaces[(who, what)], kpi_intro, kpis[{kpi, def, target, source, how, cadence}],
  capture, sources[(name, what)] ≤5, ninety[(title, detail)] ×4, owner, owner_note?`.
  Every charter renders to exactly 3 pages; if one spills to 4, shorten the mission or
  the owns list (the two-column blocks do not fragment across pages).
- Charter rules: KPIs are read together, never one alone; the anti-metrics line is on
  every charter; every KPI row says how it is captured automatically and from which
  event source; the AI Assurance charter keeps D23's independence clauses verbatim.
- KPI definitions are registered in the warehouse by Analytics & Knowledge Tools; a
  KPI without a query is refused. Targets are decisions (DECISIONS.md), not edits.

## 11. Open items

- The Intelligence Platform starts on 1 January 2027; the three pilots start
  with it and decide at end-June 2027. The communication months in TOM §10
  are proposed; the order is not.
- Pilot products and pilot leads are not yet named. Three empty boxes read as
  an intention; named people read as a decision.
- The sixth executive seat (options considered: Operations Transformation,
  Estate, AI Trust) is deliberately absent from the org chart until chosen.
- Indicative sizing throughout (50/35/40/35/20 across platforms and the
  office) is authored, not measured. Replace with the real establishment.
- Whether the marketing content platform's PO, and those for Finance &
  Oversight and Regulatory & Control, sit with the business or stay with the
  CTOO — depends on how those functions report.
