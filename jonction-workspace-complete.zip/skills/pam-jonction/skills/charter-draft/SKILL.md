---
name: charter-draft
description: Draft or review a pod charter - the dual key (Business Outcome Owner and Tech Product Builder, with the tech lead's release key), members, loops owned, registered agents against the cap of five, decision rights, escalation, release approval, service levels, on-call model, capacity tax and interfaces. Use this when a pod or squad is formed or reformed, before a breakthrough cell or a first loop starts, at the quarterly charter refresh, when a team is unclear who decides what, or when decision rights are being argued about in a delivery meeting. A cell that starts without a written charter cannot be evaluated afterwards, because nobody agreed in advance what was being tested.
---

# The pod charter

One page, in the repository root, reviewed quarterly. It is the first of the five entry
conditions for the pod's test in the Investment Platform's build-and-release
breakthrough experiment, and the reason that test can be judged rather than merely
described.

## What a pod is, and is not

Four to six people holding one product **end to end** — definition, build, test, release
and run — with three to five registered agents as capacity. It differs from a squad in
four respects that are design choices, not properties of the word:

- it is **smaller**
- it owns **the path from intent to run** rather than a stage of it
- it holds **explicit decision rights**, including a token budget
- it carries **named agents with autonomy tiers**

Renaming a team without those four changes is fashion, and a board reads that
correctly. Until the June 2027 decision on that experiment, and then Gate 4, the unit is still a
squad and the charter says so.

**Never fewer than four people on a regulated path.** Three-person configurations are
for internal tools with low blast radius. A team too small to sustain a rota is an
operational resilience weakness before it is an efficiency gain.

## The three structural constraints to write down

**The dual key.** The **Business Outcome Owner**, in the business, holds the business
key — what and why, and the outcome KPI. They co-sign the executable spec and the pod's
OKRs and manage nobody in the pod; no reporting line moves. The **Tech Product Builder**,
in the pod (the product owner's role as it now works; product owners stay in technology),
holds the technology key — how the product is defined and built, and the order of the
queue. The **tech lead** holds correctness and physically holds the release key. Neither
side overrules the other; disagreement escalates to the platform lead and the business
head **jointly, the same day**, not into a backlog. Decisions come with a working
prototype, never with a deck alone.

**The capacity tax.** Twenty to twenty-five per cent of capacity reserved for exposure,
security, upgrades and decommissioning. Set by the CTOO office; **nobody can spend it on
features**, whichever key they hold. When it is under pressure the tech lead says so at the quarterly
review rather than quietly lending it out.

**The cap of five.** At most five *registered, pod-owned* agents. Shared platform agents
do not count against it. The cap is not bureaucracy — it is the honest limit of what
four to six people can supervise. That ceiling, not model capability, is what limits
how fast a pod can go, and making it explicit before an incident discovers it is the
whole point.

## What the pod does not own

Golden sets (AI Assurance) · models and routing (Intelligence Platform) · the primitives
and connectors it consumes · the entitlement model · the definitions in the firm graph.
**Building any of these locally is the fastest way to make a pod unsupportable.** Say so
in the charter so it is a decision rather than a drift.

## Output

```
POD CHARTER · <name> · v<n> · <date>

PRODUCT           <product> · platform <platform> · physically sits <where>
DUAL KEY          business key: Business Outcome Owner <name, business role> (what, why, outcome KPI)
                  technology key: Tech Product Builder <name> (definition, build, order of work)
                  release key: tech lead <name> (correctness)
                  ← no named Outcome Owner: the charter is not ready
MEMBERS           <name, role, chapter, % allocation>
                  ... never fewer than four on a regulated path
DRAWN FROM CHAPTERS  <craft, for what defined piece of work, until when>

LOOPS OWNED       <loop> · tier <n> · business owner <name>
                  ...
REGISTERED AGENTS <n> of 5 owned · <name, tier, one line> ...
                  shared platform agents configured: <list — not against the cap>
                  <if a slot is deliberately unused, say why — it reads as judgment>

DECIDES ALONE     Outcome Owner: what and why; scope accepted or deferred
                  TPB: order of work, what ships when, within the agreed outcome
                  TL: design, safe to ship, tier proposals, pausing a loop
                  Engineers: implementation, tool and context design, rule-before-model
                  Analyst: specification structure, what counts as checkable
ESCALATES         <what, to whom, within what time>
                  ambiguity in a business rule → back to the manager, never resolved internally

RELEASE APPROVAL  four eyes always, including on agent-authored change.
                  approver is someone who did not write the change.
SERVICE LEVELS    <per loop> · error budget <>
ON-CALL           three-line support: automation → rotation → building engineer last
                  rotation: <who, how often>
CAPACITY TAX      <%> reserved · spent this quarter on <what>
INTERFACES        <other pods, platforms, FDEs — and the mode of each>
                  FDEs: solid line to the platform lead, dotted line to the FDE lead
OKRS              <one or two this quarter> · co-signed by the Outcome Owner: yes/no
                  ← run okr-check on the draft before the quarterly session
MEASURES REPORTED delivery · loop health per loop · cost · health and hygiene
                  (health metrics sit on the health dashboard, never in the OKRs)
REVIEW            quarterly · next <date>
```

## Reviewing an existing charter

Five things that are wrong most often: a dual key with no named Business Outcome Owner,
or one that takes the product owner out of technology, which the model does not do; agents listed that are actually shared platform agents counted against the cap; a capacity tax stated but visibly spent on features; an
escalation path with no time attached; and a release approver who is the same person as
the author on agent-authored change — which is precisely where four eyes matters most.
