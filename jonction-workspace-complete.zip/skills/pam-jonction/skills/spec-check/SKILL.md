---
name: spec-check
description: Check an executable spec against the Intent to Outcome contract - intent, constraints, acceptance tests, evals, controls and risk tier, versioned beside the code and co-signed by the Business Outcome Owner and the Tech Product Builder. Use this before agents start building against a spec, when a spec changes, when a team asks whether its requirements are good enough for an agent to act on, when a request arrives as a slide or a ticket instead of a spec, or when a pull request has no spec id behind it. The spec is the contract between the business and technology and the thing agents are judged by, so an unsigned or uncheckable one means nobody has agreed what success is.
---

# Checking the executable spec

The executable spec is the contract between the two keys. The Business Outcome Owner
states the intent and owns the outcome; the Tech Product Builder, with the analyst,
turns it into something an agent can build against and a reviewer can judge. Both sign
it. Agents build to it, and the evidence is read against it.

It is the product-level contract. For a loop, the eleven fields of `loop-spec` sit inside
it, mostly under constraints and controls; run that skill for the loop and this one for
the contract around it.

## The six parts

**1 · Intent.** The outcome, in the business's words, and the outcome KPI it moves, with
a baseline. Written or confirmed by the Business Outcome Owner. A solution ("build an
agent that…") is not an intent; ask what changes for the business if it works.

**2 · Constraints.** What it may not do. The rules it reads and never writes, named as
artefacts. The books it touches and the act class on each. Entitlements propagated to
the human caller. Data it may not use, residency, the cost ceiling per instance and per
day. A constraint that cannot be tested is a wish.

**3 · Acceptance tests.** Executable, written before build, run in the pipeline. They
cover the out-of-scope and negative cases, not only the happy path. "The user is
satisfied" is not a test.

**4 · Evals.** The evaluation suite by category with its thresholds, the category
regression rule, and a pointer to the golden set. **The pointer only.** The set is held
by AI Assurance and nobody building against the spec sees it; this skill never reads it.
Development examples are named separately.

**5 · Controls.** Which of the five controls per book apply (read-restricted,
contract-only, amend-restricted, rules, provenance-required), the human checkpoint per
tier, four eyes on release, the kill switch, provenance on any figure that leaves the
firm, and the registry entry the agents will carry.

**6 · Risk tier.** The proposed autonomy tier and the review gate it implies. One step at
a time; nothing reaches tier 3 in its first year; business-facing agents wait for Gate
2, anything client-facing for Gate 3. Higher risk means more review, never a faster path.

## Signatures

Both named individuals, dated, on **this version**: the Business Outcome Owner and the
Tech Product Builder. A change to intent, constraints or acceptance tests is a new
version and is signed again. The signatures do not replace the tech lead's release key or
AI Assurance's verdict; they sit beside them.

## Where it lives

In the repository, beside the code, versioned with it. The spec id and version travel in
pull-request metadata and loop traces, because area 01 asks for all agent work to run from
a versioned spec by mid-2027 and that is how it is counted. A spec in a document store
drifts within a month and is worse than none, because people trust it.

## Gaps go back, they do not get filled

An empty or vague part is a question for its owner: intent to the Business Outcome Owner,
everything else to the Tech Product Builder and the analyst. Filling it with an assumption
is how an agent ends up correctly building something nobody wanted. A spec with a gap is
grounds for the first legitimate refusal in `refusal-check`.

## Output

```
SPEC CHECK · <product or loop> · spec <id> v<n> · <date>

INTENT            <one line> · outcome KPI <> · baseline <> · stated by Outcome Owner: yes/no
CONSTRAINTS       rules named, never written: yes/no · books and act classes: <>
                  entitlements propagate: yes/no · cost ceilings per instance and day: yes/no
ACCEPTANCE TESTS  <n> · executable in the pipeline: yes/no · negative cases: yes/no
EVALS             suite <id> · categories <n> · thresholds set: yes/no
                  golden set pointer <id> (held by AI Assurance, not read)
CONTROLS          <which of the five> · checkpoint per tier: yes/no · kill switch: yes/no
                  provenance required: yes/no/n.a. · registry entry drafted: yes/no
RISK TIER         proposed tier <n> · review gate <> · gate dependency (2/3): <>
SIGNATURES        Business Outcome Owner <name, date> | missing
                  Tech Product Builder <name, date> | missing
                  signed version matches current version: yes/no
LOCATION          repository path <> · id carried in PR metadata: yes/no

VERDICT           ready for agents | return to owner
RETURNED          <each gap, and whose question it is>
```

## Then

`loop-spec` for each loop inside the product, `eval-design` for the suite, `loop-classify`
for the act classes, and `pr-check` on every change built against the spec.
