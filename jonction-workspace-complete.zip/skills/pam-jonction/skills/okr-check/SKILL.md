---
name: okr-check
description: Check a draft OKR set against the Intent to Outcome rules - the right level, a link to a Tech-wide objective, outcomes rather than activity, never AI usage, at least one key result in the Business Outcome Owner's language, the Outcome Owner's co-signature, dependencies named, and health metrics kept out. Use this in week minus two of every quarter before drafts go to the OKR session, when a team or platform asks whether its objectives are any good, when a key result counts tokens, licences, agents launched or people using AI, when an availability or incident target has crept into an OKR, or when someone proposes OKRs for individuals. A weak OKR set survives the quarter and teaches everyone that objectives are paperwork, so check it before the session rather than after the scoring.
---

# Checking an OKR set

OKRs in Jonction measure change. They are few, open to everyone in technology, and never
used to rate a person. The charters' KPIs and the resilience thresholds measure health,
and they sit on the health dashboard as guardrails. **OKRs are not KPIs.** Most bad OKR
sets fail on that one confusion.

## The three levels, and nothing below them

| Level | Owner | How many |
|---|---|---|
| **Tech-wide** | The CTOO and the leadership team, endorsed by the Executive Committee | Three objectives a quarter, three or four key results each; each objective is the next step on one of the ten areas |
| **Value stream / product** | The Business Outcome Owner and the Tech Product Builder, jointly | One or two |
| **Platform and chapter** | Platform leads; chapter leads | One or two each |

**No individual OKRs.** People contribute to their team's. A draft that names a person as
the owner of a key result is returned whatever its quality.

## The eight checks

**1 · Level.** Says which of the three levels it is, and stays within the count for that
level. Five objectives at product level is a backlog, not a set of objectives.

**2 · Alignment.** Every objective below Tech-wide points to one named Tech-wide
objective. "Supports the strategy" is not a pointer.

**3 · Outcome, not activity.** A key result describes a change in the world, with a
baseline and a target: *"idea-to-production median from 20 days to 5"*. *"Launch ten
agents"*, *"run three workshops"* and *"deliver the platform"* are activity. The test:
could the key result be met while nothing the business sees improves? If yes, rewrite it.

**4 · Never AI usage.** No key result counts tokens, licences, seats, prompts, agents
launched or the share of people using AI. Nor lines of generated code, story points or
headcount saved. Firms that scored usage reversed it within a year; we start where they
ended.

**5 · Business-readable.** Every product OKR carries at least one key result in the
Business Outcome Owner's language — cost per fund report, exception rate, time to market
for a share class, aged breaks. If the Outcome Owner would need a translation, it is a
technology key result wearing a business label.

**6 · Co-signature.** Every product OKR is co-signed by its Business Outcome Owner. If the
Outcome Owner will not sign, it is not a value-stream objective; return it, do not
soften it.

**7 · Dependencies named.** Each OKR names the products, platform teams or chapters it
depends on. An unnamed dependency becomes a conflict discovered in week eight; a named
one is decided in the room in week minus one.

**8 · Health metrics kept out.** Availability, DORA resilience, incident service levels,
audit findings, security posture and the charters' KPIs do not appear as key results.
They are guardrails. The draft states which guardrails it must not breach, because **no
OKR counts as achieved if it pushed a health metric into the red.**

## Also check

- **Scorable.** Each key result has a baseline and a target so it can be scored 0 to 1
  at quarter end; 0.7 is a good result, below 0.3 triggers a re-plan. A key result that
  will obviously score 1.0 is not a stretch.
- **Captured automatically.** The weekly check-in is drafted by an agent from Jira, Git,
  the pipeline, the gateway and business data, and confirmed in two minutes. A key result
  that needs a person to assemble its number every week will stop being updated.
- **Open by default.** Restricted key results (unannounced products, client names, HR
  matters) are flagged and visible to owners only. More than one in ten restricted means
  the set is hiding something.

## Decision rights to state, not re-argue

Tech-wide objectives: the CTOO, endorsed by the Executive Committee. Product OKRs: the
Business Outcome Owner and the Tech Product Builder together; the CTOO challenges only
for alignment. A key result changed mid-quarter: by the team, with a published reason in
the decision log. Conflicts between products: decided at the quarterly OKR session, in
the room, with owners named.

## Output

```
OKR CHECK · <team or product> · Q<n> <year> · draft v<n>

LEVEL             Tech-wide | value stream / product | platform | chapter
                  count <n> objectives · within limit: yes/no
OWNERS            <Outcome Owner, Tech Product Builder | platform lead | chapter lead>
                  any individual named as a KR owner: yes/no   ← yes returns the set

OBJECTIVE <n>     <text>
  points to       Tech-wide objective <ref> · area <nn>
  depends on      <products, teams, chapters> | none named   ← fail
  KR <n.m>        <text>
                  baseline <> · target <> · scorable: yes/no
                  outcome or activity: <>
                  AI usage or anti-metric: none | <which>      ← fail
                  in the Outcome Owner's language: yes/no
                  captured automatically from: <source> | assembled by hand
  guardrails      <health metrics it must not breach>
CO-SIGNED         Business Outcome Owner <name, date> | missing   ← fail for a product OKR
HEALTH METRICS AS KRs   none | <which, and move to the health dashboard>
RESTRICTED        <n> of <n> key results

VERDICT           ready for the session | return with changes
CHANGES           <each, with the rewrite proposed>
```

## What this skill will not do

Choose the objective. That is a decision for the owners at the level concerned. The
skill tells you whether a draft obeys the rules and proposes a rewrite where it does not;
it does not make an outcome matter that the business has not said matters.
